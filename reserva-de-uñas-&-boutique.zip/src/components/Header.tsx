/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Sparkles, Calendar, ShoppingBag, ShieldCheck, LogOut } from 'lucide-react';

interface HeaderProps {
  currentTab: 'booking' | ' boutique';
  setCurrentTab: (tab: 'booking' | ' boutique') => void;
  isAdminMode: boolean;
  setIsAdminMode: (mode: boolean) => void;
  isLoggedIn: boolean;
  onLogout: () => void;
  onOpenLoginModal: () => void;
  shopName: string;
}

export default function Header({
  currentTab,
  setCurrentTab,
  isAdminMode,
  setIsAdminMode,
  isLoggedIn,
  onLogout,
  onOpenLoginModal,
  shopName
}: HeaderProps) {
  return (
    <header className="h-20 border-b border-pink-500/20 bg-slate-950/60 backdrop-blur-md flex items-center justify-between px-4 sm:px-10 shrink-0 sticky top-0 z-40">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 bg-gradient-to-tr from-pink-300 via-slate-400 to-pink-100 rounded-full flex items-center justify-center shadow-lg shadow-pink-500/10 border border-slate-300/30">
          <span className="text-slate-950 font-serif font-bold text-xl italic">N</span>
        </div>
        <div className="flex flex-col">
          <h1 className="text-lg sm:text-2xl font-serif italic text-pink-100 tracking-wide font-semibold">
            {shopName || 'NailArt Elite'}
          </h1>
          <span className="text-[9px] font-mono tracking-widest text-slate-400 uppercase hidden sm:inline-block">
            Pastel & Chrome Nails
          </span>
        </div>
      </div>
      
      {/* Search / Nav */}
      {!isAdminMode && (
        <nav className="flex gap-4 sm:gap-8 text-xs sm:text-sm uppercase tracking-widest font-medium">
          <button 
            onClick={() => setCurrentTab('booking')}
            className={`flex items-center gap-2 pb-1 transition-all border-b-2 cursor-pointer ${
              currentTab === 'booking' 
                ? 'text-pink-400 border-pink-400 font-semibold' 
                : 'text-slate-400 border-transparent hover:text-pink-300'
            }`}
          >
            <Calendar className="w-4 h-4 text-pink-400/80" />
            <span className="hidden xs:inline">Servicios</span>
          </button>
          <button 
            onClick={() => setCurrentTab(' boutique')}
            className={`flex items-center gap-2 pb-1 transition-all border-b-2 cursor-pointer ${
              currentTab === ' boutique' 
                ? 'text-pink-400 border-pink-400 font-semibold' 
                : 'text-slate-400 border-transparent hover:text-pink-300'
            }`}
          >
            <ShoppingBag className="w-4 h-4 text-pink-400/80" />
            <span className="hidden xs:inline">Boutique</span>
          </button>
        </nav>
      )}

      {isAdminMode && (
        <div className="text-xs uppercase tracking-widest text-pink-400 flex items-center gap-2 font-semibold">
          <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse shadow-[0_0_8px_#4ade80]"></span>
          Panel Administrativo
        </div>
      )}

      <div className="flex items-center gap-2 sm:gap-4">
        {isLoggedIn ? (
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setIsAdminMode(!isAdminMode)}
              className="px-3 sm:px-4 py-1.5 rounded-full border border-pink-400/30 text-pink-200 text-xs font-semibold hover:bg-pink-950/40 transition-all flex items-center gap-1.5"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-pink-400" />
              <span className="hidden sm:inline">{isAdminMode ? 'Ver Sitio Público' : 'Ir a Panel Admin'}</span>
              <span className="sm:hidden">{isAdminMode ? 'Público' : 'Admin'}</span>
            </button>
            <button 
              onClick={onLogout}
              className="p-1.5 rounded-full bg-slate-900 border border-slate-800 text-slate-400 hover:text-pink-400 hover:border-pink-500/20 transition-all"
              title="Cerrar Sesión"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <button 
            onClick={onOpenLoginModal}
            className="px-3 sm:px-5 py-2 rounded-full border border-slate-700 hover:border-pink-500/40 text-slate-300 hover:text-pink-100 text-xs font-semibold hover:bg-slate-900 transition-all uppercase tracking-wider cursor-pointer"
          >
            Ingresar Admin
          </button>
        )}
      </div>
    </header>
  );
}
