/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Calendar, 
  Trash2, 
  Edit3, 
  Plus, 
  Check, 
  X, 
  Settings, 
  ShoppingBag, 
  Clock, 
  Sparkles, 
  Phone, 
  Instagram, 
  Layers, 
  HelpCircle, 
  DollarSign, 
  Users, 
  CheckSquare, 
  MapPin,
  Save,
  Lock,
  ArrowUpRight,
  Send,
  Loader2
} from 'lucide-react';
import { NailService, Product, Appointment, ProductOrder, AdminSettings, DashboardStats } from '../types';

interface AdminPanelProps {
  services: NailService[];
  products: Product[];
  appointments: Appointment[];
  orders: ProductOrder[];
  stats: DashboardStats;
  settings: AdminSettings;
  onUpdateSettings: (newSettings: any) => Promise<boolean>;
  onCreateService: (srv: any) => Promise<boolean>;
  onUpdateService: (id: string, srv: any) => Promise<boolean>;
  onDeleteService: (id: string) => Promise<boolean>;
  onCreateProduct: (prod: any) => Promise<boolean>;
  onUpdateProduct: (id: string, prod: any) => Promise<boolean>;
  onDeleteProduct: (id: string) => Promise<boolean>;
  onUpdateAppointmentStatus: (id: string, status: string) => Promise<boolean>;
  onTriggerReminder: (id: string) => Promise<boolean>;
  onUpdateOrderStatus: (id: string, status: string) => Promise<boolean>;
  onDeleteAppointment: (id: string) => Promise<boolean>;
  onDeleteOrder: (id: string) => Promise<boolean>;
}

type AdminTab = 'appointments' | 'orders' | 'services' | 'products' | 'settings';

export default function AdminPanel({
  services,
  products,
  appointments,
  orders,
  stats,
  settings,
  onUpdateSettings,
  onCreateService,
  onUpdateService,
  onDeleteService,
  onCreateProduct,
  onUpdateProduct,
  onDeleteProduct,
  onUpdateAppointmentStatus,
  onTriggerReminder,
  onUpdateOrderStatus,
  onDeleteAppointment,
  onDeleteOrder
}: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState<AdminTab>('appointments');

  // --- FORMS STATES ---
  // Store Settings Form
  const [shopName, setShopName] = useState(settings.shopName);
  const [welcomeMessage, setWelcomeMessage] = useState(settings.welcomeMessage);
  const [whatsapp, setWhatsapp] = useState(settings.whatsapp);
  const [instagram, setInstagram] = useState(settings.instagram);
  const [address, setAddress] = useState(settings.address);
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [settingsMsg, setSettingsMsg] = useState({ text: '', type: '' });
  const [isSavingSettings, setIsSavingSettings] = useState(false);

  // Sync settings when loaded
  useEffect(() => {
    setShopName(settings.shopName);
    setWelcomeMessage(settings.welcomeMessage);
    setWhatsapp(settings.whatsapp);
    setInstagram(settings.instagram);
    setAddress(settings.address);
  }, [settings]);

  // Nail Service Modal/Form
  const [editingService, setEditingService] = useState<NailService | null>(null);
  const [showServiceForm, setShowServiceForm] = useState(false);
  const [serviceName, setServiceName] = useState('');
  const [serviceDesc, setServiceDesc] = useState('');
  const [servicePrice, setServicePrice] = useState('');
  const [serviceDuration, setServiceDuration] = useState('60');

  // Product Modal/Form
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [showProductForm, setShowProductForm] = useState(false);
  const [productName, setProductName] = useState('');
  const [productDesc, setProductDesc] = useState('');
  const [productPrice, setProductPrice] = useState('');
  const [productInStock, setProductInStock] = useState(true);

  // Local notifications
  const [actionAlert, setActionAlert] = useState({ text: '', type: '' });

  const showAlert = (text: string, type: 'success' | 'error' = 'success') => {
    setActionAlert({ text, type });
    setTimeout(() => setActionAlert({ text: '', type: '' }), 4000);
  };

  // --- LOGIC HANDLERS ---
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSettingsMsg({ text: '', type: '' });

    if (newPassword && newPassword !== confirmPassword) {
      setSettingsMsg({ text: 'Las contraseñas no coinciden', type: 'error' });
      return;
    }

    setIsSavingSettings(true);
    const updatedValues: any = {
      shopName,
      welcomeMessage,
      whatsapp,
      instagram,
      address
    };
    if (newPassword) {
      updatedValues.newPassword = newPassword;
    }

    const success = await onUpdateSettings(updatedValues);
    setIsSavingSettings(false);
    if (success) {
      setSettingsMsg({ text: '¡Configuración guardada correctamente con éxito!', type: 'success' });
      setNewPassword('');
      setConfirmPassword('');
    } else {
      setSettingsMsg({ text: 'Error al actualizar configuraciones en el servidor', type: 'error' });
    }
  };

  // Nail Services logic
  const handleOpenServiceCreate = () => {
    setEditingService(null);
    setServiceName('');
    setServiceDesc('');
    setServicePrice('');
    setServiceDuration('60');
    setShowServiceForm(true);
  };

  const handleOpenServiceEdit = (srv: NailService) => {
    setEditingService(srv);
    setServiceName(srv.name);
    setServiceDesc(srv.description);
    setServicePrice(srv.price.toString());
    setServiceDuration(srv.durationMinutes.toString());
    setShowServiceForm(true);
  };

  const handleServiceSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!serviceName.trim() || !servicePrice) {
      showAlert('El nombre y el precio final son obligatorios.', 'error');
      return;
    }

    const srvPayload = {
      name: serviceName.trim(),
      description: serviceDesc.trim(),
      price: Number(servicePrice),
      durationMinutes: Number(serviceDuration)
    };

    if (editingService) {
      const ok = await onUpdateService(editingService.id, srvPayload);
      if (ok) showAlert('Servicio actualizado con éxito.');
    } else {
      const ok = await onCreateService(srvPayload);
      if (ok) showAlert('Servicio creado e incorporado correctamente.');
    }
    setShowServiceForm(false);
  };

  const handleDeleteServiceClick = async (id: string, name: string) => {
    if (window.confirm(`¿Estás segura de eliminar el servicio "${name}"?`)) {
      const ok = await onDeleteService(id);
      if (ok) showAlert('Servicio eliminado.');
    }
  };

  // Products logic
  const handleOpenProductCreate = () => {
    setEditingProduct(null);
    setProductName('');
    setProductDesc('');
    setProductPrice('');
    setProductInStock(true);
    setShowProductForm(true);
  };

  const handleOpenProductEdit = (prod: Product) => {
    setEditingProduct(prod);
    setProductName(prod.name);
    setProductDesc(prod.description);
    setProductPrice(prod.price.toString());
    setProductInStock(prod.inStock);
    setShowProductForm(true);
  };

  const handleProductSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!productName.trim() || !productPrice) {
      showAlert('El nombre y el precio del artículo son obligatorios.', 'error');
      return;
    }

    const prodPayload = {
      name: productName.trim(),
      description: productDesc.trim(),
      price: Number(productPrice),
      inStock: productInStock
    };

    if (editingProduct) {
      const ok = await onUpdateProduct(editingProduct.id, prodPayload);
      if (ok) showAlert('Producto boutique actualizado con éxito.');
    } else {
      const ok = await onCreateProduct(prodPayload);
      if (ok) showAlert('Producto agregado con éxito al catálogo.');
    }
    setShowProductForm(false);
  };

  const handleDeleteProductClick = async (id: string, name: string) => {
    if (window.confirm(`¿Estás segura de eliminar el producto de boutique "${name}"?`)) {
      const ok = await onDeleteProduct(id);
      if (ok) showAlert('Producto boutique retirado correctamente.');
    }
  };

  const handleDeleteAppointmentClick = async (id: string, clientName: string) => {
    if (window.confirm(`¿Deseas dar de baja y eliminar el registro de turno de "${clientName}"?`)) {
      const ok = await onDeleteAppointment(id);
      if (ok) showAlert('Turno purgado de la lista.');
    }
  };

  const handleDeleteOrderClick = async (id: string, clientName: string) => {
    if (window.confirm(`¿Deseas dar de baja y borrar la solicitud de pedido de "${clientName}"?`)) {
      const ok = await onDeleteOrder(id);
      if (ok) showAlert('Pedido purgado de la lista.');
    }
  };

  // Status transitions
  const handleAcceptAppointment = async (id: string) => {
    const ok = await onUpdateAppointmentStatus(id, 'aceptado');
    if (ok) showAlert('Turno aceptado. Listo para recibir aviso.');
  };

  const handleRejectAppointment = async (id: string) => {
    const ok = await onUpdateAppointmentStatus(id, 'rechazado');
    if (ok) showAlert('Turno rechazado.');
  };

  const handleUpdateOrderStatusClick = async (id: string, status: string) => {
    const ok = await onUpdateOrderStatus(id, status);
    if (ok) showAlert(`Pedido boutique marcado como ${status.toUpperCase()}.`);
  };

  // WhatsApp Reminder Integration
  const handleSendWhatsAppReminder = async (apt: Appointment) => {
    // 1. Mark as reminded on backend
    await onTriggerReminder(apt.id);

    // 2. Prep WhatsApp prefilled text
    // Clean spaces and special chars in phone or try to prepend country code if needed
    let cleanPhone = apt.clientPhone.replace(/[\s\-\(\)\+]/g, '');
    if (!cleanPhone.startsWith('54') && cleanPhone.length === 10) {
      // Default to Argentina code if empty or 10 digits
      cleanPhone = '549' + cleanPhone;
    }
    
    const dateFormatted = apt.date.split('-').reverse().join('/');
    const textMsg = `Hola ${apt.clientName}! Te recordamos tu turno de uñas para realizarte *${apt.serviceName}* en *${settings.shopName}* el día *${dateFormatted}* a las *${apt.time} hs*. ¡Te esperamos! 💅💖✨`;
    const encryptedMsg = encodeURIComponent(textMsg);
    
    // 3. Open WhatsApp link dynamically in a new tab
    const waUrl = `https://api.whatsapp.com/send?phone=${cleanPhone}&text=${encryptedMsg}`;
    window.open(waUrl, '_blank');
    showAlert('Mensaje de recordatorio preparado y enviado por WhatsApp.');
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8 animate-fadeIn">
      {/* Action Notification Hub Alert */}
      {actionAlert.text && (
        <div className={`fixed bottom-6 right-6 z-50 px-5 py-3 rounded-2xl shadow-xl flex items-center gap-2 border animate-bounce ${
          actionAlert.type === 'success' 
            ? 'bg-slate-900 border-green-500/30 text-green-400' 
            : 'bg-slate-900 border-red-500/30 text-red-400'
        }`}>
          <div className={`w-2 h-2 rounded-full ${actionAlert.type === 'success' ? 'bg-green-400' : 'bg-red-400'}`}></div>
          <span className="text-xs font-semibold uppercase tracking-wider">{actionAlert.text}</span>
        </div>
      )}

      {/* Stats Summary Bento Section */}
      <section className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Turnos Hoy', value: stats.todayAppointmentsCount || 0, desc: 'Agendados hoy', color: 'border-pink-500/20' },
          { label: 'En Espera', value: stats.pendingAppointmentsCount || 0, desc: 'Turnos pendientes', color: 'border-pink-400/30 text-pink-300' },
          { label: 'Pedidos Boutique', value: stats.pendingOrdersCount || 0, desc: 'Artículos pedidos', color: 'border-slate-800 text-pink-200' },
          { label: 'Clientes Unicos', value: stats.totalClientsCount || 0, desc: 'En base de datos', color: 'border-slate-800' }
        ].map((item, idx) => (
          <div key={idx} className={`bg-slate-900/40 border rounded-3xl p-5 flex flex-col justify-between select-none ${item.color}`}>
            <span className="text-[10px] text-slate-500 uppercase tracking-widest font-mono font-medium">{item.label}</span>
            <div className="my-2 flex items-baseline">
              <span className="text-3xl sm:text-4xl font-serif italic text-white font-bold">{item.value}</span>
            </div>
            <span className="text-[10px] text-slate-400 font-mono leading-none">{item.desc}</span>
          </div>
        ))}
      </section>

      {/* Tabs Menu Navigation Custom */}
      <section className="flex border-b border-slate-900 overflow-x-auto pb-0">
        {[
          { id: 'appointments', label: 'Turnos Registrados', icon: Calendar },
          { id: 'orders', label: 'Pedidos Boutique', icon: ShoppingBag },
          { id: 'services', label: 'Tipos de Uña (Servicios)', icon: Layers },
          { id: 'products', label: 'Catálogo de Artículos', icon: CheckSquare },
          { id: 'settings', label: 'Estudio & Cuenta', icon: Settings }
        ].map((tab) => {
          const IconComponent = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as AdminTab)}
              className={`flex items-center gap-2 px-5 py-3 cursor-pointer text-xs font-semibold uppercase tracking-wider border-b-2 whitespace-nowrap transition-all ${
                isActive 
                  ? 'border-pink-400 text-pink-300 font-bold' 
                  : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-800'
              }`}
            >
              <IconComponent className={`w-4 h-4 ${isActive ? 'text-pink-400' : 'text-slate-500'}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </section>

      {/* Main Tab Render Container */}
      <section className="min-h-96">
        
        {/* TAB 1: Appointments List Management */}
        {activeTab === 'appointments' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center flex-wrap gap-4">
              <div>
                <h3 className="text-xl font-serif italic text-pink-100 font-semibold">Turnos Totales Recibidos</h3>
                <p className="text-slate-400 text-xs">Aceptá clientes desde tu celular e inicia el whatsapp con los recordatorios directos.</p>
              </div>
            </div>

            {appointments.length === 0 ? (
              <div className="py-16 text-center text-slate-500 bg-slate-900/10 border border-slate-850 rounded-3xl">
                No hay turnos registrados en la base de datos aún.
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-4">
                {appointments
                  .slice()
                  .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                  .map((apt) => {
                    const statusColors: Record<string, string> = {
                      pendiente: 'bg-orange-500/10 text-orange-400 border border-orange-550/20',
                      aceptado: 'bg-green-500/10 text-green-400 border border-green-500/20',
                      rechazado: 'bg-red-500/10 text-red-400 border border-red-500/20'
                    };
                    const dateFormatted = apt.date.split('-').reverse().join('/');
                    
                    return (
                      <div 
                        key={apt.id}
                        className={`bg-slate-900/40 border rounded-3xl p-5 sm:p-6 transition-all flex flex-col md:flex-row justify-between gap-6 ${
                          apt.status === 'pendiente' ? 'border-pink-500/10 bg-pink-500/2' : 'border-slate-850'
                        }`}
                      >
                        {/* Appointment main info */}
                        <div className="flex-1 space-y-4">
                          <div className="flex items-center gap-3 flex-wrap">
                            <span className="text-md sm:text-lg font-bold text-slate-100">{apt.clientName}</span>
                            <span className={`text-[10px] uppercase font-mono font-bold tracking-wider px-2 py-0.5 rounded-full ${statusColors[apt.status]}`}>
                              {apt.status === 'pendiente' ? 'En Espera' : apt.status}
                            </span>
                          </div>
                          
                          {/* Details line */}
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs text-slate-300">
                            <div className="flex items-center gap-1.5">
                              <Calendar className="w-3.5 h-3.5 text-pink-400" />
                              <span className="font-mono">{dateFormatted}</span>
                            </div>
                            <div className="flex items-center gap-1.5">
                              <Clock className="w-3.5 h-3.5 text-pink-400" />
                              <span className="font-mono">{apt.time} hs</span>
                            </div>
                            <div className="flex items-center gap-1.5">
                              <DollarSign className="w-3.5 h-3.5 text-pink-400" />
                              <span className="font-semibold">{apt.serviceName} (${apt.price})</span>
                            </div>
                          </div>

                          <div className="space-y-1.5 text-xs">
                            <div className="flex items-center gap-4 text-slate-400">
                              <span className="flex items-center gap-1.5 font-mono">
                                <Phone className="w-3.5 h-3.5 text-slate-500" />
                                {apt.clientPhone}
                              </span>
                              {apt.clientInstagram && (
                                <span className="flex items-center gap-1 hover:text-pink-300 font-mono">
                                  <Instagram className="w-3.5 h-3.5 text-slate-500" />
                                  @{apt.clientInstagram}
                                </span>
                              )}
                            </div>
                            {apt.notes && (
                              <p className="bg-slate-950/70 border border-slate-850 p-2.5 rounded-xl text-[11px] text-slate-400 leading-normal max-w-xl">
                                <strong className="text-slate-300 text-[10px] block mb-0.5 uppercase tracking-wide">Notas de Diseño / Ideas:</strong>
                                "{apt.notes}"
                              </p>
                            )}
                          </div>
                        </div>

                        {/* Actions column */}
                        <div className="flex md:flex-col justify-end items-stretch md:items-end gap-2.5 min-w-[180px] border-t md:border-t-0 pt-4 md:pt-0 border-slate-900">
                          {apt.status === 'pendiente' && (
                            <div className="flex gap-2 w-full md:w-auto">
                              <button
                                onClick={() => handleAcceptAppointment(apt.id)}
                                className="flex-1 md:flex-none uppercase tracking-wider font-semibold cursor-pointer px-4 py-2 bg-green-500 text-slate-950 hover:bg-green-400 rounded-xl text-xs flex items-center justify-center gap-1"
                              >
                                <Check className="w-4 h-4" />
                                Aceptar
                              </button>
                              <button
                                onClick={() => handleRejectAppointment(apt.id)}
                                className="flex-1 md:flex-none uppercase tracking-wider font-semibold cursor-pointer px-3 py-2 bg-slate-950 hover:bg-rose-950/30 text-rose-500 border border-slate-850 rounded-xl text-xs flex items-center justify-center"
                                title="Rechazar Turno"
                              >
                                <X className="w-4 h-4" />
                              </button>
                            </div>
                          )}

                          {apt.status === 'aceptado' && (
                            <button
                              onClick={() => handleSendWhatsAppReminder(apt)}
                              className={`w-full text-center py-2.5 px-4 font-bold tracking-wide rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                                apt.reminderSent
                                  ? 'bg-slate-950 text-emerald-400 border border-emerald-500/20 hover:bg-emerald-950/10'
                                  : 'bg-emerald-500 text-slate-950 hover:bg-emerald-400 shadow-[0_0_8px_rgba(16,185,129,0.2)]'
                              }`}
                            >
                              <Send className="w-3.5 h-3.5" />
                              <span>{apt.reminderSent ? 'Re-enviar Recordatorio' : 'Enviar Recordatorio (WhatsApp)'}</span>
                            </button>
                          )}

                          {apt.status === 'rechazado' && (
                            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block self-center md:self-end">Turno Cancelado</span>
                          )}

                          <button
                            onClick={() => handleDeleteAppointmentClick(apt.id, apt.clientName)}
                            className="p-2 bg-slate-950 text-slate-500 hover:text-red-400 hover:border-red-950 rounded-xl border border-slate-850 transition-all cursor-pointer flex items-center justify-center shrink-0 self-center md:self-end"
                            title="Eliminar registro"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
              </div>
            )}
          </div>
        )}

        {/* TAB 2: Product Requests list */}
        {activeTab === 'orders' && (
          <div className="space-y-6">
            <div>
              <h3 className="text-xl font-serif italic text-pink-100 font-semibold">Pedidos de Boutique (Productos)</h3>
              <p className="text-slate-400 text-xs">Control de solicitudes de esmaltes, adhesivas, tips y accesorios independientes del servicio de manicura.</p>
            </div>

            {orders.length === 0 ? (
              <div className="py-16 text-center text-slate-500 bg-slate-900/10 border border-slate-850 rounded-3xl">
                No hay pedidos de productos registrados actualmente.
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-4">
                {orders
                  .slice()
                  .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                  .map((order) => {
                    const statusStyles: Record<string, string> = {
                      pendiente: 'bg-orange-500/10 text-orange-400 border border-orange-550/20',
                      listo: 'bg-pink-500/10 text-pink-300 border border-pink-550/20',
                      entregado: 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                    };
                    
                    return (
                      <div key={order.id} className="bg-slate-900/40 border border-slate-850 rounded-3xl p-5 sm:p-6 flex flex-col md:flex-row justify-between gap-6">
                        <div className="flex-1 space-y-3">
                          <div className="flex items-center gap-3 flex-wrap">
                            <span className="text-md sm:text-lg font-bold text-slate-100">{order.clientName}</span>
                            <span className={`text-[10px] uppercase font-mono font-bold tracking-wider px-2 py-0.5 rounded-full ${statusStyles[order.status]}`}>
                              {order.status === 'listo' ? 'Listo para retirar' : order.status}
                            </span>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                            <div className="text-slate-300">
                              <span className="text-slate-500">Producto solicitado:</span>
                              <p className="font-semibold text-white">{order.productName} <span className="font-mono font-normal text-slate-400">({order.quantity} u.)</span></p>
                            </div>
                            <div className="text-slate-300">
                              <span className="text-slate-500">Total a abonar:</span>
                              <p className="font-semibold text-pink-300 font-serif italic text-md">${order.total}.00</p>
                            </div>
                          </div>

                          <div className="space-y-1.5 text-xs text-slate-400">
                            <div className="flex items-center gap-4">
                              <span className="flex items-center gap-1 font-mono">
                                <Phone className="w-3.5 h-3.5 text-slate-500" />
                                {order.clientPhone}
                              </span>
                              {order.clientInstagram && (
                                <span className="flex items-center gap-1 font-mono">
                                  <Instagram className="w-3.5 h-3.5 text-slate-500" />
                                  @{order.clientInstagram}
                                </span>
                              )}
                            </div>
                            {order.notes && (
                              <p className="bg-slate-950/70 border border-slate-850 p-2.5 rounded-xl text-[11px] text-slate-400">
                                <strong className="text-slate-300 text-[10px] block mb-0.5">Indicaciones de Pedido:</strong>
                                "{order.notes}"
                              </p>
                            )}
                          </div>
                        </div>

                        {/* Transition operations */}
                        <div className="flex md:flex-col justify-end gap-2 items-stretch md:items-end min-w-[160px] border-t md:border-t-0 pt-4 md:pt-0 border-slate-900">
                          {order.status === 'pendiente' && (
                            <button
                              onClick={() => handleUpdateOrderStatusClick(order.id, 'listo')}
                              className="w-full text-center py-2 bg-pink-500 text-slate-950 hover:bg-pink-400 rounded-xl text-xs font-bold uppercase tracking-wider cursor-pointer"
                            >
                              Marcar Listo para Retiro
                            </button>
                          )}

                          {order.status === 'listo' && (
                            <button
                              onClick={() => handleUpdateOrderStatusClick(order.id, 'entregado')}
                              className="w-full text-center py-2 bg-emerald-500 text-slate-950 hover:bg-emerald-400 rounded-xl text-xs font-bold uppercase tracking-wider cursor-pointer"
                            >
                              Confirmar Entrega
                            </button>
                          )}

                          {order.status === 'entregado' && (
                            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-widest block py-2">✓ Entregado & Finalizado</span>
                          )}

                          <div className="flex gap-2">
                            {/* Short WA direct coordination logic too */}
                            <a
                              href={`https://api.whatsapp.com/send?phone=${order.clientPhone.replace(/[\s\-\(\)\+]/g, '')}&text=${encodeURIComponent(`Hola ${order.clientName}! Te escribo de ${settings.shopName} sobre tu pedido de boutique de: *${order.productName}*`)}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="px-3 py-1.5 bg-slate-950 hover:bg-slate-900 text-slate-300 border border-slate-850 rounded-xl text-xs flex items-center justify-center gap-1 hover:text-pink-300"
                            >
                              <Phone className="w-3.5 h-3.5 text-pink-400" />
                              <span>Coordinar</span>
                            </a>
                            <button
                              onClick={() => handleDeleteOrderClick(order.id, order.clientName)}
                              className="p-2 bg-slate-950 text-slate-500 hover:text-red-400 border border-slate-850 rounded-xl cursor-pointer"
                              title="Borrar pedido"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
              </div>
            )}
          </div>
        )}

        {/* TAB 3: Customizable Nail Services Editor */}
        {activeTab === 'services' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-xl font-serif italic text-pink-100 font-semibold">Tipos de Uñas & Tratamientos</h3>
                <p className="text-slate-400 text-xs">Añadí, editá o elimina estilos de uñas y configura los precios que verán tus clientas.</p>
              </div>
              <button
                onClick={handleOpenServiceCreate}
                className="px-4 py-2 bg-pink-500 hover:bg-pink-400 text-slate-950 font-display font-semibold uppercase tracking-wider text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow-lg shadow-pink-500/10"
              >
                <Plus className="w-4 h-4" />
                <span>Nuevo Servicio</span>
              </button>
            </div>

            {/* Custom Edit/Create Inline Dialog Form */}
            {showServiceForm && (
              <form 
                onSubmit={handleServiceSubmit} 
                className="bg-slate-900 border border-pink-400/30 p-6 rounded-3xl space-y-4 animate-fadeIn"
              >
                <span className="text-[10px] uppercase font-bold tracking-widest text-pink-300">
                  {editingService ? 'Editar Servicio de Uña' : 'Cargar Nuevo Servicio de Uña'}
                </span>
                
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="space-y-1 sm:col-span-1">
                    <label className="text-xs text-slate-400">Nombre del Tratamiento *</label>
                    <input
                      type="text"
                      required
                      value={serviceName}
                      onChange={(e) => setServiceName(e.target.value)}
                      placeholder="Ej: Kapping Gel Rosé"
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-pink-500/20"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs text-slate-400">Precio (en USD / pesos) *</label>
                    <input
                      type="number"
                      required
                      value={servicePrice}
                      onChange={(e) => setServicePrice(e.target.value)}
                      placeholder="Ej: 30"
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-pink-500/20"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs text-slate-400">Duración estimada (minutos)</label>
                    <input
                      type="number"
                      value={serviceDuration}
                      onChange={(e) => setServiceDuration(e.target.value)}
                      placeholder="Ej: 60"
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-pink-500/20"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-slate-400">Descripción / Detalles del tratamiento</label>
                  <textarea
                    value={serviceDesc}
                    onChange={(e) => setServiceDesc(e.target.value)}
                    rows={2}
                    placeholder="Describe los materiales, el tipo de acabado o decoraciones básicas que se incluyen en el precio base."
                    className="w-full bg-slate-950 border border-slate-850 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none"
                  />
                </div>

                <div className="flex justify-end gap-2.5 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowServiceForm(false)}
                    className="px-4 py-2 bg-slate-950 border border-slate-850 hover:bg-slate-900 text-slate-400 rounded-xl text-xs font-semibold cursor-pointer"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-pink-500 hover:bg-pink-400 text-slate-950 rounded-xl text-xs font-semibold hover:shadow-lg hover:shadow-pink-400/15 cursor-pointer"
                  >
                    {editingService ? 'Actualizar' : 'Guardar'}
                  </button>
                </div>
              </form>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {services.map((srv) => (
                <div key={srv.id} className="bg-slate-900/40 border border-slate-850 rounded-3xl p-5 flex flex-col justify-between hover:border-pink-500/20 transition-all">
                  <div>
                    <div className="flex justify-between items-start gap-4 mb-2">
                      <h4 className="text-md font-bold text-white tracking-wide">{srv.name}</h4>
                      <div className="bg-slate-950/60 rounded-xl border border-slate-850 px-3 py-1 font-serif italic text-pink-300 font-bold shrink-0">
                        ${srv.price}.00
                      </div>
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed mt-1">{srv.description || 'Sin explicación técnica.'}</p>
                    <span className="text-[10px] text-slate-500 block font-mono mt-3">Duración estimada: {srv.durationMinutes || 60} minutos</span>
                  </div>

                  <div className="flex justify-end gap-2 mt-4 pt-3 border-t border-slate-900">
                    <button
                      onClick={() => handleOpenServiceEdit(srv)}
                      className="p-2 bg-slate-950 text-slate-400 hover:text-pink-300 border border-slate-850 rounded-xl transition-all cursor-pointer flex items-center justify-center"
                      title="Editar servicio"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDeleteServiceClick(srv.id, srv.name)}
                      className="p-2 bg-slate-950 text-slate-500 hover:text-red-400 border border-slate-850 rounded-xl transition-all cursor-pointer flex items-center justify-center"
                      title="Eliminar servicio"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 4: Customizable Products Inventory Editor */}
        {activeTab === 'products' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-xl font-serif italic text-pink-100 font-semibold">Inventario de Artículos (Boutique)</h3>
                <p className="text-slate-400 text-xs">Cargá productos físicos de cosmética para que las clientas puedan pedírtelos por fuera de los turnos normales de manicuría.</p>
              </div>
              <button
                onClick={handleOpenProductCreate}
                className="px-4 py-2 bg-pink-500 hover:bg-pink-400 text-slate-950 font-display font-semibold uppercase tracking-wider text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow-lg shadow-pink-500/10"
              >
                <Plus className="w-4 h-4" />
                <span>Nuevo Producto</span>
              </button>
            </div>

            {/* Custom Product form in container inline */}
            {showProductForm && (
              <form 
                onSubmit={handleProductSubmit}
                className="bg-slate-900 border border-pink-400/30 p-6 rounded-3xl space-y-4 animate-fadeIn"
              >
                <span className="text-[10px] uppercase font-bold tracking-widest text-pink-300">
                  {editingProduct ? 'Editar Producto Boutique' : 'Agregar Nuevo Producto Boutique'}
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="space-y-1 sm:col-span-1">
                    <label className="text-xs text-slate-400">Nombre del Producto *</label>
                    <input
                      type="text"
                      required
                      value={productName}
                      onChange={(e) => setProductName(e.target.value)}
                      placeholder="Ej: Esmalte Reflejo Chrome"
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs text-slate-400">Precio de venta ($) *</label>
                    <input
                      type="number"
                      required
                      value={productPrice}
                      onChange={(e) => setProductPrice(e.target.value)}
                      placeholder="Ej: 12"
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none"
                    />
                  </div>
                  <div className="space-y-2 flex flex-col justify-end pb-1.5">
                    <label className="text-xs text-slate-400 mb-1">Disponibilidad en Stock</label>
                    <label className="flex items-center gap-2 cursor-pointer text-xs">
                      <input 
                        type="checkbox"
                        checked={productInStock}
                        onChange={(e) => setProductInStock(e.target.checked)}
                        className="w-4.5 h-4.5 accent-pink-500 rounded cursor-pointer"
                      />
                      <span className="text-slate-300">¿Habilitado con stock disponible?</span>
                    </label>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-slate-400">Descripción / Detalles adicionales del esmalte o accesorio</label>
                  <textarea
                    value={productDesc}
                    onChange={(e) => setProductDesc(e.target.value)}
                    rows={2}
                    placeholder="Detalla colores, tamaño del envase, marca, o instrucciones de retiro..."
                    className="w-full bg-slate-950 border border-slate-850 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none"
                  />
                </div>

                <div className="flex justify-end gap-2.5 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowProductForm(false)}
                    className="px-4 py-2 bg-slate-950 border border-slate-850 hover:bg-slate-900 text-slate-400 rounded-xl text-xs font-semibold cursor-pointer"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-pink-500 hover:bg-pink-400 text-slate-950 rounded-xl text-xs font-semibold cursor-pointer"
                  >
                    {editingProduct ? 'Actualizar' : 'Guardar'}
                  </button>
                </div>
              </form>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {products.map((prod) => (
                <div key={prod.id} className="bg-slate-900/40 border border-slate-850 rounded-3xl p-5 flex flex-col justify-between hover:border-pink-500/20 transition-all">
                  <div className="space-y-2">
                    <div className="flex justify-between gap-4">
                      <div>
                        <h4 className="text-md font-bold text-white tracking-wide">{prod.name}</h4>
                        <span className={`text-[9px] font-mono inline-block px-2 py-0.5 mt-1 rounded ${
                          prod.inStock ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'
                        }`}>
                          {prod.inStock ? 'Habilitado con stock' : 'Fuera de Stock'}
                        </span>
                      </div>
                      <div className="bg-slate-950/60 rounded-xl border border-slate-850 px-3 py-1.5 font-serif italic text-pink-300 font-bold shrink-0">
                        ${prod.price}.00
                      </div>
                    </div>
                    <p className="text-xs text-slate-400 leading-normal">{prod.description || 'Sin descripción.'}</p>
                  </div>

                  <div className="flex justify-end gap-2 mt-4 pt-3 border-t border-slate-900">
                    <button
                      onClick={() => handleOpenProductEdit(prod)}
                      className="p-2 bg-slate-950 text-slate-400 hover:text-pink-300 border border-slate-850 rounded-xl transition-all cursor-pointer flex items-center justify-center"
                      title="Editar producto"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDeleteProductClick(prod.id, prod.name)}
                      className="p-2 bg-slate-950 text-slate-500 hover:text-red-400 border border-slate-850 rounded-xl transition-all cursor-pointer flex items-center justify-center"
                      title="Eliminar producto"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 5: Store settings customizer & admin logs */}
        {activeTab === 'settings' && (
          <div className="space-y-6 max-w-2xl">
            <div>
              <h3 className="text-xl font-serif italic text-pink-100 font-semibold">Configuración del Estudio</h3>
              <p className="text-slate-400 text-xs">Ajustá la información comercial, tus redes sociales y cambia la contraseña de administrador para ingresar.</p>
            </div>

            <form onSubmit={handleSaveSettings} className="bg-slate-900/40 border border-slate-850 rounded-3xl p-6 space-y-5">
              
              <div className="space-y-3">
                <span className="text-[10px] uppercase font-bold tracking-wider text-pink-400 block pb-1 border-b border-slate-900">Información del Negocio</span>
                
                {/* Store Name */}
                <div className="space-y-1">
                  <label className="text-xs text-slate-450 block font-medium">Nombre de de la Marca / Salón *</label>
                  <input
                    type="text"
                    required
                    value={shopName}
                    onChange={(e) => setShopName(e.target.value)}
                    placeholder="Ej: NailArt Elite Studio"
                    className="w-full bg-slate-950 border border-slate-850 rounded-xl px-4 py-2.5 text-xs text-white"
                  />
                </div>

                {/* Physical Address */}
                <div className="space-y-1">
                  <label className="text-xs text-slate-450 block font-medium">Dirección Física del Local</label>
                  <input
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="Ej: Av. Santa Fe 3400, Palermo"
                    className="w-full bg-slate-950 border border-slate-850 rounded-xl px-4 py-2.5 text-xs text-white"
                  />
                </div>

                {/* Studio Welcome Banner Message */}
                <div className="space-y-1">
                  <label className="text-xs text-slate-450 block font-medium">Mensaje de Bienvenida al Cliente</label>
                  <textarea
                    value={welcomeMessage}
                    onChange={(e) => setWelcomeMessage(e.target.value)}
                    rows={3}
                    placeholder="Describe tus especialidades..."
                    className="w-full bg-slate-950 border border-slate-850 rounded-xl px-4 py-2.5 text-xs text-white resize-none"
                  />
                </div>
              </div>

              <div className="space-y-3 pt-2">
                <span className="text-[10px] uppercase font-bold tracking-wider text-pink-400 block pb-1 border-b border-slate-900">Redes Sociales & Links Directos</span>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* WhatsApp Support */}
                  <div className="space-y-1">
                    <label className="text-xs text-slate-450 block font-medium">Teléfono / WhatsApp Comercial *</label>
                    <input
                      type="text"
                      required
                      value={whatsapp}
                      onChange={(e) => setWhatsapp(e.target.value)}
                      placeholder="Ej: +5491155556666"
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl px-4 py-2.5 text-xs text-white"
                    />
                    <span className="text-[9px] text-slate-500 block">Número completo con código de país, sin espacios</span>
                  </div>

                  {/* Instagram Username */}
                  <div className="space-y-1">
                    <label className="text-xs text-slate-450 block font-medium">Usuario de Instagram *</label>
                    <input
                      type="text"
                      required
                      value={instagram}
                      onChange={(e) => setInstagram(e.target.value)}
                      placeholder="nailart_studio"
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl px-4 py-2.5 text-xs text-white"
                    />
                    <span className="text-[9px] text-slate-500 block">Nombre de usuario sin el símbolo @</span>
                  </div>
                </div>
              </div>

              <div className="space-y-3 pt-2">
                <span className="text-[10px] uppercase font-bold tracking-wider text-pink-400 block pb-1 border-b border-slate-900">Seguridad de la Cuenta Directa</span>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Password Changer */}
                  <div className="space-y-1">
                    <label className="text-xs text-slate-450 block font-medium">Nueva Contraseña de Acceso</label>
                    <input
                      type="password"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="Dejar vacío para mantener contraseña original"
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl px-4 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-none"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs text-slate-450 block font-medium">Confirmar Nueva Contraseña</label>
                    <input
                      type="password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Escribe de nuevo tu contraseña"
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl px-4 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {settingsMsg.text && (
                <div className={`p-3 rounded-xl text-xs text-center border ${
                  settingsMsg.type === 'success' 
                    ? 'bg-green-950/20 text-green-400 border-green-900/40' 
                    : 'bg-red-950/20 text-red-400 border-red-900/40'
                }`}>
                  {settingsMsg.text}
                </div>
              )}

              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  disabled={isSavingSettings}
                  className="px-6 py-3 bg-pink-500 hover:bg-pink-400 text-slate-950 text-xs font-bold font-display uppercase tracking-wider rounded-xl cursor-pointer flex items-center gap-1.5 shadow-lg hover:shadow-pink-400/20"
                >
                  {isSavingSettings ? (
                    <Loader2 className="w-4 h-4 animate-spin text-slate-950" />
                  ) : (
                    <Save className="w-4 h-4 text-slate-950" />
                  )}
                  <span>Guardas Cambios de Configuración</span>
                </button>
              </div>
            </form>
          </div>
        )}
      </section>
    </div>
  );
}
