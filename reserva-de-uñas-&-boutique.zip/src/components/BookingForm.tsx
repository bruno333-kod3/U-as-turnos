/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Calendar, Clock, User, Phone, Instagram, FileText, CheckCircle2, Sparkles, HelpCircle } from 'lucide-react';
import { NailService, Appointment } from '../types';

interface BookingFormProps {
  services: NailService[];
  existingAppointments: Appointment[];
  onSubmitBooking: (bookingData: any) => Promise<boolean>;
  shopSettings: {
    shopName: string;
    welcomeMessage: string;
    whatsapp: string;
  };
}

// Generate next 14 days helper
const getNext14Days = () => {
  const days = [];
  const weekdays = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
  const months = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
  
  for (let i = 0; i < 14; i++) {
    const d = new Date();
    d.setDate(d.getDate() + i);
    
    // We can skip Sundays if salon is closed, or allow it. Let's list it anyway but display label if closed.
    days.push({
      dateStr: d.toISOString().split('T')[0],
      dayName: weekdays[d.getDay()],
      dayNum: d.getDate(),
      monthLabel: months[d.getMonth()],
      dayOfWeek: d.getDay()
    });
  }
  return days;
};

// Available daily slots
const TIME_SLOTS = [
  '09:30',
  '11:00',
  '12:30',
  '14:00',
  '15:30',
  '17:00',
  '18:30',
  '20:00'
];

export default function BookingForm({
  services,
  existingAppointments,
  onSubmitBooking,
  shopSettings
}: BookingFormProps) {
  const nextDays = getNext14Days();
  
  // Form States
  const [selectedService, setSelectedService] = useState<NailService | null>(null);
  const [selectedDate, setSelectedDate] = useState<string>(nextDays[0].dateStr);
  const [selectedTime, setSelectedTime] = useState<string>('');
  
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [clientInstagram, setClientInstagram] = useState('');
  const [notes, setNotes] = useState('');
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successBooking, setSuccessBooking] = useState<any>(null);
  const [errorMessage, setErrorMessage] = useState('');

  // Default select first service once loaded
  useEffect(() => {
    if (services.length > 0 && !selectedService) {
      setSelectedService(services[0]);
    }
  }, [services]);

  // Clean time slot when date changes
  useEffect(() => {
    setSelectedTime('');
  }, [selectedDate]);

  // Check if slot is already occupied
  const getSlotStatus = (time: string) => {
    const match = existingAppointments.find(
      (apt) => apt.date === selectedDate && apt.time === time && apt.status !== 'rechazado'
    );
    if (match) {
      return match.status === 'aceptado' ? 'ocupado' : 'pendiente_aprobacion';
    }
    return 'disponible';
  };

  const handleBookingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    
    if (!selectedService) {
      setErrorMessage('Por favor, selecciona un tipo de servicio de uñas.');
      return;
    }
    if (!selectedDate) {
      setErrorMessage('Por favor, selecciona una fecha.');
      return;
    }
    if (!selectedTime) {
      setErrorMessage('Por favor, elige un horario disponible.');
      return;
    }
    if (!clientName.trim()) {
      setErrorMessage('Por favor, escribe tu nombre completo.');
      return;
    }
    if (!clientPhone.trim()) {
      setErrorMessage('Por favor, escribe tu teléfono de contacto.');
      return;
    }

    setIsSubmitting(true);
    
    const bookingData = {
      clientName: clientName.trim(),
      clientPhone: clientPhone.trim(),
      clientInstagram: clientInstagram.trim().replace('@', ''),
      date: selectedDate,
      time: selectedTime,
      serviceId: selectedService.id,
      notes: notes.trim()
    };

    try {
      const success = await onSubmitBooking(bookingData);
      if (success) {
        setSuccessBooking({
          serviceName: selectedService.name,
          price: selectedService.price,
          date: selectedDate,
          time: selectedTime,
          clientName: clientName.trim()
        });
        
        // Reset inputs
        setClientName('');
        setClientPhone('');
        setClientInstagram('');
        setNotes('');
        setSelectedTime('');
      } else {
        setErrorMessage('Ocurrió un error al procesar tu turno. Inténtalo de nuevo.');
      }
    } catch (err) {
      setErrorMessage('Hubo un problema de red. Reintenta por favor.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (successBooking) {
    // Beautiful success ticket screen
    return (
      <div className="bg-slate-900/60 border border-pink-500/30 rounded-3xl p-8 max-w-xl mx-auto shadow-2xl text-center backdrop-blur-md animate-fadeIn">
        <div className="w-16 h-16 bg-pink-500/20 border border-pink-400 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle2 className="w-10 h-10 text-pink-400" />
        </div>
        <h3 className="text-3xl font-serif italic text-pink-100 mb-2">¡Solicitud Enviada!</h3>
        <p className="text-sm text-slate-300 mb-6">
          Hola <strong className="text-white">{successBooking.clientName}</strong>, tu cita ha sido registrada y está en espera de confirmación.
        </p>

        <div className="bg-slate-950/80 rounded-2xl p-5 border border-slate-800 text-left space-y-3 mb-6 max-w-full">
          <div className="flex justify-between items-center text-xs pb-2 border-b border-slate-900">
            <span className="text-slate-400">Estudio:</span>
            <span className="text-pink-300 font-bold">{shopSettings.shopName}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-xs text-slate-400">Servicio de Uñas:</span>
            <span className="text-sm font-semibold text-slate-100">{successBooking.serviceName}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-xs text-slate-400">Precio Estimado:</span>
            <span className="text-sm text-pink-400 font-semibold">${successBooking.price}.00</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-xs text-slate-400">Fecha elegida:</span>
            <span className="text-sm font-mono text-slate-200">
              {successBooking.date.split('-').reverse().join('/')}
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-xs text-slate-400">Horario:</span>
            <span className="text-sm font-mono text-slate-200">{successBooking.time} hs</span>
          </div>
        </div>

        <div className="bg-pink-500/5 p-4 rounded-xl border border-pink-500/20 text-left mb-6">
          <span className="text-[10px] uppercase font-bold text-pink-400 tracking-wider block mb-1">PROCESO DE AVISO</span>
          <p className="text-xs text-slate-300 leading-relaxed">
            Te llegará un <strong>mensaje de recordatorio</strong> directo a tu celular por WhatsApp o SMS una vez que confirmemos tu horario elegido. ¡Gracias por confiar en {shopSettings.shopName}!
          </p>
        </div>

        <button 
          onClick={() => setSuccessBooking(null)}
          className="px-6 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl text-xs font-bold uppercase tracking-widest transition-all w-full border border-slate-700 cursor-pointer"
        >
          Pedir Otro Turno
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6 lg:flex-row max-w-7xl mx-auto items-stretch">
      {/* Services List Column - 60% */}
      <div className="lg:w-3/5 flex flex-col gap-6">
        <div className="bg-slate-900/40 border border-pink-500/10 rounded-3xl p-6 sm:p-8 flex-1 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-start mb-6">
              <div>
                <span className="text-[10px] text-pink-400 uppercase tracking-widest block mb-1">Paso 1: Selecciona el Estilo</span>
                <h2 className="text-3xl sm:text-4xl font-serif italic text-pink-100">Nuestros Servicios</h2>
                <p className="text-slate-400 text-xs sm:text-sm mt-1">Elegí el tratamiento que querés para tus uñas</p>
              </div>
              <div className="text-right hidden sm:block">
                <span className="text-[10px] text-slate-500 font-mono">ESTILO EXCLUSIVO</span>
                <div className="h-0.5 w-16 bg-gradient-to-r from-pink-400 to-transparent mt-1"></div>
              </div>
            </div>

            {services.length === 0 ? (
              <div className="py-12 text-center text-slate-500">
                No hay servicios cargados por el momento.
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {services.map((service) => {
                  const isSelected = selectedService?.id === service.id;
                  return (
                    <div 
                      key={service.id}
                      onClick={() => setSelectedService(service)}
                      className={`group p-5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
                        isSelected 
                          ? 'bg-pink-500/10 border-pink-400/80 shadow-lg ring-1 ring-pink-400/40' 
                          : 'bg-slate-900/60 border-slate-800 hover:border-pink-500/30'
                      }`}
                    >
                      <div>
                        <div className="flex justify-between items-start mb-2">
                          <span className={`text-[10px] font-mono font-medium px-2 py-0.5 rounded-full ${
                            isSelected ? 'bg-pink-400/20 text-pink-300' : 'bg-slate-800 text-slate-400'
                          }`}>
                            {service.durationMinutes} min
                          </span>
                          <span className="text-lg font-serif italic text-pink-200 font-semibold">
                            ${service.price}.00
                          </span>
                        </div>
                        <h3 className="text-md font-semibold text-slate-100 group-hover:text-pink-300 transition-colors">
                          {service.name}
                        </h3>
                        <p className="text-xs text-slate-400 mt-1.5 leading-relaxed line-clamp-3">
                          {service.description || 'Sin explicación provista.'}
                        </p>
                      </div>
                      
                      <div className="mt-4 flex justify-end items-center">
                        <span className={`text-[10px] uppercase font-bold tracking-wider ${
                          isSelected ? 'text-pink-300' : 'text-slate-500 group-hover:text-pink-400/60'
                        }`}>
                          {isSelected ? '✓ Seleccionado' : 'Elegir'}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 mt-6 flex flex-col xs:flex-row items-center gap-4">
            <div className="w-10 h-10 rounded-full bg-pink-500/10 flex items-center justify-center shrink-0 border border-pink-500/25">
              <Sparkles className="w-5 h-5 text-pink-400" />
            </div>
            <div>
              <h4 className="text-xs font-semibold text-slate-300">¿Buscás un diseño 100% único y detallado?</h4>
              <p className="text-[11px] text-slate-500 mt-0.5 leading-snug">
                Podes seleccionar cualquier servicio base y luego escribir tus ideas exactas de esmaltado, dibujos o detalles en gris metalizado de cromo en el campo de notas al final de tu reserva.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Date, Time & Contact Form Column - 40% */}
      <div className="lg:w-2/5 mt-6 lg:mt-0 flex">
        <form 
          onSubmit={handleBookingSubmit}
          className="bg-slate-900/40 border border-slate-800 rounded-3xl p-6 sm:p-8 flex-1 flex flex-col justify-between"
        >
          <div className="space-y-6">
            <div>
              <span className="text-[10px] text-pink-400 uppercase tracking-widest block mb-1">Paso 2: Fecha y Hora</span>
              <h3 className="text-xl font-serif text-pink-100 italic">Disponibilidad de Turno</h3>
            </div>

            {/* Date Carousel */}
            <div>
              <label className="text-xs text-slate-400 block mb-2 font-medium">Seleccioná el día:</label>
              <div className="flex gap-2.5 overflow-x-auto pb-3 scrollbar-thin scrollbar-thumb-pink-500/20 scrollbar-track-transparent">
                {nextDays.map((day) => {
                  const isSelected = selectedDate === day.dateStr;
                  const isSunday = day.dayOfWeek === 0;
                  return (
                    <button
                      key={day.dateStr}
                      type="button"
                      disabled={isSunday}
                      onClick={() => setSelectedDate(day.dateStr)}
                      className={`w-13 h-18 rounded-xl flex flex-col items-center justify-center border transition-all shrink-0 cursor-pointer ${
                        isSunday
                          ? 'bg-slate-950 opacity-20 border-transparent cursor-not-allowed'
                          : isSelected
                            ? 'bg-pink-400 text-slate-950 border-pink-300 shadow-md font-bold'
                            : 'bg-slate-950 border-slate-850 text-slate-300 hover:border-pink-500/20'
                      }`}
                    >
                      <span className={`text-[9px] uppercase tracking-wider ${isSelected ? 'text-slate-900 font-bold' : 'text-slate-500'}`}>
                        {day.dayName}
                      </span>
                      <span className="text-lg font-display my-0.5">{day.dayNum}</span>
                      <span className={`text-[8px] uppercase ${isSelected ? 'text-slate-905 font-bold' : 'text-slate-400'}`}>
                        {day.monthLabel}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Time Slot Picker */}
            <div>
              <label className="text-xs text-slate-400 block mb-2 font-medium">Seleccioná un horario:</label>
              <div className="grid grid-cols-4 gap-2">
                {TIME_SLOTS.map((time) => {
                  const isSelected = selectedTime === time;
                  const status = getSlotStatus(time);
                  const isOccupied = status === 'ocupado';
                  const isPendingApprove = status === 'pendiente_aprobacion';
                  
                  let btnStyle = "bg-slate-950 border-slate-850 hover:border-pink-550/20 text-slate-300 cursor-pointer";
                  if (isSelected) {
                    btnStyle = "bg-pink-500/30 text-pink-300 border-pink-400/80 ring-1 ring-pink-400/30 font-semibold cursor-pointer";
                  } else if (isOccupied) {
                    btnStyle = "bg-red-950/20 border-red-900/30 text-rose-800 line-through cursor-not-allowed opacity-50";
                  } else if (isPendingApprove) {
                    btnStyle = "bg-orange-950/25 border-orange-900/30 text-orange-400/70";
                  }

                  return (
                    <button
                      key={time}
                      type="button"
                      disabled={isOccupied}
                      onClick={() => setSelectedTime(time)}
                      className={`py-2 rounded-lg text-xs font-mono border text-center transition-all ${btnStyle}`}
                      title={
                        isOccupied 
                          ? 'Ocupado' 
                          : isPendingApprove 
                            ? 'Pendiente de aprobación' 
                            : 'Disponible'
                      }
                    >
                      {time}
                      {isPendingApprove && !isSelected && (
                        <span className="block text-[8px] text-orange-400 scale-90">Espera</span>
                      )}
                    </button>
                  );
                })}
              </div>
              <div className="flex gap-4 mt-2.5 text-[10px] text-slate-500 font-mono">
                <div className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded bg-slate-950 border border-slate-800 inline-block"></span>
                  <span>Libre</span>
                </div>
                <div className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded bg-orange-950/20 border border-orange-90030 inline-block text-orange-400"></span>
                  <span>Pendiente</span>
                </div>
                <div className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded bg-red-950/20 border border-red-900/50 inline-block"></span>
                  <span>Ocupado</span>
                </div>
              </div>
            </div>

            {/* Client Inputs */}
            <div className="space-y-3.5 pt-4 border-t border-slate-850">
              <span className="text-[10px] text-pink-400 uppercase tracking-widest block mb-1">Paso 3: Datos de Contacto</span>
              
              {/* Full Name */}
              <div className="space-y-1">
                <label className="text-xs text-slate-400 flex items-center gap-1">
                  <User className="w-3.5 h-3.5 text-pink-400/80" />
                  <span>Nombre Completo *</span>
                </label>
                <input
                  type="text"
                  required
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  placeholder="Ej: Bianca Gómez"
                  className="w-full bg-slate-950 border border-slate-850 rounded-xl px-4 py-2.5 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-pink-500/40"
                />
              </div>

              {/* Phone */}
              <div className="space-y-1">
                <label className="text-xs text-slate-400 flex items-center gap-1">
                  <Phone className="w-3.5 h-3.5 text-pink-400/80" />
                  <span>Número de Celular *</span>
                </label>
                <input
                  type="tel"
                  required
                  value={clientPhone}
                  onChange={(e) => setClientPhone(e.target.value)}
                  placeholder="Ej: +54 9 11 5555 1234"
                  className="w-full bg-slate-950 border border-slate-850 rounded-xl px-4 py-2.5 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-pink-500/40"
                />
                <span className="text-[9px] text-slate-500 block">Esencial para enviarte el recordatorio de tu turno</span>
              </div>

              {/* Instagram */}
              <div className="space-y-1">
                <label className="text-xs text-slate-400 flex items-center gap-1">
                  <Instagram className="w-3.5 h-3.5 text-pink-400/80" />
                  <span>Instagram (Opcional)</span>
                </label>
                <input
                  type="text"
                  value={clientInstagram}
                  onChange={(e) => setClientInstagram(e.target.value)}
                  placeholder="@usuario_instagram"
                  className="w-full bg-slate-950 border border-slate-850 rounded-xl px-4 py-2.5 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-pink-500/40"
                />
              </div>

              {/* Notes */}
              <div className="space-y-1">
                <label className="text-xs text-slate-400 flex items-center gap-1">
                  <FileText className="w-3.5 h-3.5 text-pink-400/80" />
                  <span>Detalles de Diseño / Comentarios (Opcional)</span>
                </label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={2}
                  placeholder="Estilos de decoraciones preferidas (esmalte cromado, colores pasteles, apliques, etc.)"
                  className="w-full bg-slate-950 border border-slate-850 rounded-xl px-4 py-2.5 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-pink-500/40 resize-none"
                />
              </div>
            </div>
          </div>

          <div className="mt-8">
            {errorMessage && (
              <div className="mb-4 bg-red-950/30 border border-red-900/50 rounded-xl p-3 text-red-400 text-xs text-center">
                {errorMessage}
              </div>
            )}

            {selectedService && (
              <div className="mb-4 p-3 bg-slate-950 border border-slate-850 rounded-xl flex justify-between items-center text-xs">
                <div>
                  <span className="text-slate-500">Servicio seleccionado:</span>
                  <p className="font-semibold text-slate-200">{selectedService.name}</p>
                </div>
                <div className="text-right">
                  <span className="text-slate-500">Total estimado:</span>
                  <p className="font-serif italic text-pink-300 font-bold text-md">${selectedService.price}.00</p>
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full cursor-pointer bg-gradient-to-r from-pink-300 via-pink-400 to-pink-200 text-slate-950 font-display font-semibold uppercase tracking-wider text-xs py-3.5 rounded-xl hover:shadow-[0_0_15px_rgba(244,114,182,0.3)] transition-all flex items-center justify-center gap-2 group-hover:scale-102"
            >
              {isSubmitting ? (
                <div className="w-5 h-5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <>
                  <span>Enviar Solicitud de Turno</span>
                  <Sparkles className="w-4 h-4 text-slate-950 animate-pulse" />
                </>
              )}
            </button>
            <span className="text-[10px] text-slate-500 text-center block mt-2 leading-relaxed">
              * El turno quedará guardado para que la manicurista lo acepte desde su celular. Recibirás tu recordatorio.
            </span>
          </div>
        </form>
      </div>
    </div>
  );
}
