/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Instagram, MapPin } from 'lucide-react';

interface FooterProps {
  shopName: string;
  instagram: string;
  address: string;
}

export default function Footer({ shopName, instagram, address }: FooterProps) {
  return (
    <footer className="py-6 border-t border-slate-900 bg-slate-950 px-4 sm:px-10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 uppercase tracking-widest shrink-0 mt-auto">
      <div className="flex items-center gap-1.5 text-center sm:text-left">
        <span>© {new Date().getFullYear()}</span>
        <span className="font-serif italic text-pink-400 font-semibold">{shopName || 'NAILART ELITE STUDIO'}</span>
        <span className="hidden sm:inline">• TODOS LOS DERECHOS RESERVADOS</span>
      </div>
      <div className="flex flex-wrap justify-center gap-4 sm:gap-6 items-center">
        {address && (
          <div className="flex items-center gap-1 text-[10px]">
            <MapPin className="w-3.5 h-3.5 text-slate-500" />
            <span>{address}</span>
          </div>
        )}
        <span className="text-pink-500/40 hidden sm:inline">•</span>
        {instagram && (
          <a 
            href={`https://instagram.com/${instagram}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 hover:text-pink-300 transition-colors text-[10px]"
          >
            <Instagram className="w-3.5 h-3.5 text-pink-400/80" />
            <span>@{instagram}</span>
          </a>
        )}
      </div>
    </footer>
  );
}
