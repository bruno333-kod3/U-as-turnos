/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ShoppingBag, ChevronRight, Sparkles, User, Phone, Instagram, FileText, CheckCircle, Package, ArrowLeft } from 'lucide-react';
import { Product } from '../types';

interface ProductCatalogProps {
  products: Product[];
  onSubmitOrder: (orderData: any) => Promise<boolean>;
  shopSettings: {
    shopName: string;
    whatsapp: string;
  };
}

export default function ProductCatalog({
  products,
  onSubmitOrder,
  shopSettings
}: ProductCatalogProps) {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  
  // Order Form states
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [clientInstagram, setClientInstagram] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [notes, setNotes] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successOrder, setSuccessOrder] = useState<any>(null);
  const [errorMessage, setErrorMessage] = useState('');

  const handleOrderSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!selectedProduct) return;
    if (!clientName.trim()) {
      setErrorMessage('Por favor, ingresá tu nombre completo.');
      return;
    }
    if (!clientPhone.trim()) {
      setErrorMessage('Por favor, ingresá tu número de teléfono.');
      return;
    }

    setIsSubmitting(true);

    const orderData = {
      clientName: clientName.trim(),
      clientPhone: clientPhone.trim(),
      clientInstagram: clientInstagram.trim().replace('@', ''),
      productId: selectedProduct.id,
      quantity,
      notes: notes.trim()
    };

    try {
      const success = await onSubmitOrder(orderData);
      if (success) {
        setSuccessOrder({
          productName: selectedProduct.name,
          price: selectedProduct.price,
          quantity,
          total: selectedProduct.price * quantity,
          clientName: clientName.trim()
        });

        // Reset inputs
        setClientName('');
        setClientPhone('');
        setClientInstagram('');
        setQuantity(1);
        setNotes('');
        setSelectedProduct(null);
      } else {
        setErrorMessage('Ocurrió un error al cargar tu pedido. Reintenta.');
      }
    } catch (err) {
      setErrorMessage('Problema de conexión con el estudio. Inténtalo de nuevo.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Pre-configured CSS designs for each product placeholder depending on name
  const renderProductGraphic = (name: string) => {
    const isPolish = name.toLowerCase().includes('esm') || name.toLowerCase().includes('polis');
    const isPressOn = name.toLowerCase().includes('press') || name.toLowerCase().includes('peg');
    
    if (isPolish) {
      return (
        <div className="w-16 h-16 bg-slate-950 rounded-2xl border border-pink-500/10 flex items-center justify-center overflow-hidden shrink-0">
          <div className="flex flex-col items-center">
            {/* Polish Cap */}
            <div className="w-3.5 h-6 bg-slate-700/80 rounded-t-sm border-t border-slate-500"></div>
            {/* Bottle body */}
            <div className="w-8 h-8 bg-gradient-to-tr from-pink-400 to-pink-300 rounded-b-md relative flex items-center justify-center shadow-[0_0_12px_rgba(244,114,182,0.3)]">
              <div className="absolute top-1 w-6 h-1 bg-white/40 rounded"></div>
              <span className="text-[7px] font-mono font-bold text-slate-950 uppercase">CHROME</span>
            </div>
          </div>
        </div>
      );
    }
    
    if (isPressOn) {
      return (
        <div className="w-16 h-16 bg-slate-950 rounded-2xl border border-pink-500/10 flex items-center justify-center overflow-hidden shrink-0 p-2">
          <div className="flex gap-1 items-end justify-center h-full">
            <div className="w-3 h-8 bg-pink-100 border-t border-slate-400 rounded-full skew-x-3 shadow-pink-300/40 shadow-sm"></div>
            <div className="w-3.5 h-10 bg-pink-300 border-t border-slate-350 rounded-full skew-x-3 -mb-1 shadow-[0_0_8px_rgba(244,114,182,0.4)]"></div>
            <div className="w-3 h-8 bg-pink-100 border-t border-slate-400 rounded-full skew-x-3 shadow-pink-300/40 shadow-sm"></div>
          </div>
        </div>
      );
    }

    // Default icon
    return (
      <div className="w-16 h-16 bg-slate-950 rounded-2xl border border-pink-500/10 flex items-center justify-center overflow-hidden shrink-0">
        <Package className="w-7 h-7 text-pink-400/80" />
      </div>
    );
  };

  if (successOrder) {
    return (
      <div className="bg-slate-900/60 border border-pink-500/30 rounded-3xl p-8 max-w-xl mx-auto shadow-2xl text-center backdrop-blur-md animate-fadeIn">
        <div className="w-16 h-16 bg-pink-500/20 border border-pink-400 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle className="w-10 h-10 text-pink-400" />
        </div>
        <h3 className="text-3xl font-serif italic text-pink-100 mb-2">¡Pedido Solicitado!</h3>
        <p className="text-sm text-slate-300 mb-6 font-medium">
          ¡Gracias <strong className="text-white">{successOrder.clientName}</strong>! Registramos tu pedido con éxito.
        </p>

        <div className="bg-slate-950/80 rounded-2xl p-5 border border-slate-800 text-left space-y-3 mb-6">
          <div className="flex justify-between items-center text-xs pb-2 border-b border-slate-900">
            <span className="text-slate-400">Concepto:</span>
            <span className="text-pink-300 font-bold">Solicitud de Producto Boutique</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-xs text-slate-400">Producto:</span>
            <span className="text-sm font-semibold text-slate-100">{successOrder.productName}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-xs text-slate-400">Cantidad:</span>
            <span className="text-sm font-mono text-slate-200">{successOrder.quantity} uni.</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-xs text-slate-400">Precio Unitario:</span>
            <span className="text-xs text-slate-400">${successOrder.price}.00</span>
          </div>
          <div className="flex justify-between items-center pt-2 border-t border-slate-900">
            <span className="text-xs text-slate-300 font-bold">Importe Total:</span>
            <span className="text-md text-pink-400 font-serif italic font-bold">${successOrder.total}.00</span>
          </div>
        </div>

        <div className="bg-pink-500/5 p-4 rounded-xl border border-pink-500/20 text-left mb-6">
          <span className="text-[10px] uppercase font-bold text-pink-400 tracking-wider block mb-1">RECOLECCIÓN / RETIRO</span>
          <p className="text-xs text-slate-300 leading-relaxed">
            La manicurista separará tu stock solicitado y <strong>te notificará directamente a tu contacto</strong> para coordinar el retiro por el local o programar el pago y envío.
          </p>
        </div>

        <button 
          onClick={() => setSuccessOrder(null)}
          className="px-6 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl text-xs font-bold uppercase tracking-widest transition-all w-full border border-slate-700 cursor-pointer"
        >
          Volver a la Boutique
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fadeIn">
      {/* Introduction Banner */}
      <div className="bg-slate-900/30 border border-slate-800/80 rounded-3xl p-6 sm:p-10 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex-1 space-y-2">
          <span className="text-[10px] text-pink-400 uppercase tracking-widest font-mono font-semibold block">
            ★ Boutique & Nail Accessories ★
          </span>
          <h2 className="text-3xl sm:text-4xl font-serif italic text-pink-100 font-semibold leading-tight">
            Nuestra Línea de Productos
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 leading-relaxed max-w-2xl">
            ¿No estás buscando un turno de service en este momento? No hay problema. Podés comprar directamente nuestros esmaltes exclusivos con brillos cromados plateados y nuestros sets artesanales de uñas listos para pegar (Press-On Nails). ¡Hechos a mano!
          </p>
        </div>
        <div className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-pink-500/5 border border-pink-400/20 max-w-xs shrink-0 self-start md:self-center">
          <Package className="w-8 h-8 text-pink-400 shrink-0" />
          <div className="text-left">
            <h4 className="text-xs font-semibold text-slate-200">Garantía de Calidad</h4>
            <span className="text-[10px] text-slate-500 leading-none">Diseñados por profesionales.</span>
          </div>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-8 items-start">
        {/* Gallery / Product list */}
        <div className="w-full lg:flex-1 grid grid-cols-1 sm:grid-cols-2 gap-5">
          {products.length === 0 ? (
            <div className="col-span-full py-16 bg-slate-900/20 rounded-3xl border border-slate-800 text-center text-slate-500">
              No hay productos cargados en la boutique actualmente.
            </div>
          ) : (
            products.map((product) => {
              const isSelected = selectedProduct?.id === product.id;
              const hasStock = product.inStock;
              
              return (
                <div 
                  key={product.id}
                  className={`bg-slate-900/40 border rounded-3xl p-5 flex flex-col justify-between gap-5 transition-all relative ${
                    isSelected 
                      ? 'border-pink-400/80 bg-pink-500/5 ring-1 ring-pink-400/30' 
                      : 'border-slate-850 hover:border-pink-500/20'
                  }`}
                >
                  {/* Stock status badge */}
                  <span className={`absolute top-4 right-4 text-[9px] font-mono px-2 py-0.5 rounded-full ${
                    hasStock 
                      ? 'bg-green-500/10 text-green-400 border border-green-500/15' 
                      : 'bg-red-500/10 text-red-400 border border-red-500/15'
                  }`}>
                    {hasStock ? 'En Stock' : 'Sin Stock'}
                  </span>

                  <div className="flex gap-4 items-start">
                    {renderProductGraphic(product.name)}
                    <div className="space-y-1 pr-14">
                      <h3 className="text-md font-semibold text-slate-100 tracking-wide">
                        {product.name}
                      </h3>
                      <p className="text-xs text-slate-400 leading-snug line-clamp-3">
                        {product.description || 'Producto artesanal de alta fidelidad.'}
                      </p>
                    </div>
                  </div>

                  <div className="flex justify-between items-center pt-3 border-t border-slate-900">
                    <div className="flex flex-col">
                      <span className="text-[9px] text-slate-500 uppercase font-mono">Importe</span>
                      <span className="text-xl font-serif italic text-pink-300 font-bold">${product.price}.00</span>
                    </div>

                    <button 
                      type="button"
                      disabled={!hasStock}
                      onClick={() => {
                        setSelectedProduct(product);
                        setQuantity(1);
                        // Scroll nicely if mobile
                        window.scrollTo({ top: document.body.scrollHeight / 2, behavior: 'smooth' });
                      }}
                      className={`px-4 py-2.5 rounded-xl text-xs font-bold font-display uppercase tracking-wider transition-all cursor-pointer ${
                        !hasStock
                          ? 'bg-slate-950 text-slate-600 border border-slate-900 cursor-not-allowed'
                          : isSelected
                            ? 'bg-pink-400 text-slate-950 hover:brightness-115'
                            : 'bg-slate-950 hover:bg-slate-900 text-slate-300 border border-slate-800 hover:border-pink-400/20'
                      }`}
                    >
                      Solicitar
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Dynamic Request Sidebar Drawer Form (when a product is clicked) */}
        {selectedProduct ? (
          <div className="w-full lg:w-96 bg-slate-900/60 border border-pink-500/25 rounded-3xl p-6 sm:p-7 sticky top-24 shadow-2xl backdrop-blur-md animate-fadeIn">
            <div className="flex justify-between items-center mb-5 pb-3 border-b border-slate-850">
              <h3 className="text-sm uppercase font-bold text-pink-300 tracking-widest flex items-center gap-2">
                <ShoppingBag className="w-4 h-4 text-pink-400" />
                Nueva Solicitud
              </h3>
              <button 
                onClick={() => setSelectedProduct(null)}
                className="text-xs text-slate-500 p-1 hover:text-white hover:bg-slate-800 rounded-full transition-all flex items-center cursor-pointer"
                title="Cancelar"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>

            <div className="mb-5 bg-slate-950/70 p-4 rounded-xl border border-slate-850 flex items-center gap-3">
              {renderProductGraphic(selectedProduct.name)}
              <div>
                <h4 className="text-xs font-bold text-slate-200 leading-tight">{selectedProduct.name}</h4>
                <p className="text-xs text-pink-300 font-semibold mt-1">${selectedProduct.price}.00 c/u</p>
              </div>
            </div>

            <form onSubmit={handleOrderSubmit} className="space-y-4 text-left">
              {/* Quantity Picker */}
              <div className="space-y-1.5">
                <label className="text-xs text-slate-400 block font-medium">Cantidad de unidades:</label>
                <div className="flex items-center gap-3">
                  <button 
                    type="button"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-10 h-10 bg-slate-950 border border-slate-850 rounded-xl flex items-center justify-center font-bold hover:border-pink-500/20 text-slate-300 text-md cursor-pointer"
                  >
                    -
                  </button>
                  <span className="w-12 text-center text-md font-mono text-white font-bold">{quantity}</span>
                  <button 
                    type="button"
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-10 h-10 bg-slate-950 border border-slate-850 rounded-xl flex items-center justify-center font-bold hover:border-pink-500/20 text-slate-300 text-md cursor-pointer"
                  >
                    +
                  </button>
                  <div className="ml-auto text-right">
                    <span className="text-[9px] text-slate-500 block uppercase">Subtotal</span>
                    <span className="text-md font-bold text-pink-300 font-serif italic">${selectedProduct.price * quantity}.00</span>
                  </div>
                </div>
              </div>

              {/* Client Name */}
              <div className="space-y-1">
                <label className="text-xs text-slate-400 flex items-center gap-1.5 font-medium">
                  <User className="w-3.5 h-3.5 text-pink-400" />
                  <span>Tu Nombre Completo *</span>
                </label>
                <input 
                  type="text"
                  required
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  placeholder="Ej: Sofía Velázquez"
                  className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3.5 py-2.5 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-pink-500/30"
                />
              </div>

              {/* Client Contact Phone */}
              <div className="space-y-1">
                <label className="text-xs text-slate-400 flex items-center gap-1.5 font-medium">
                  <Phone className="w-3.5 h-3.5 text-pink-400" />
                  <span>Celular de Contacto *</span>
                </label>
                <input 
                  type="tel"
                  required
                  value={clientPhone}
                  onChange={(e) => setClientPhone(e.target.value)}
                  placeholder="Ej: +54 9 11 ..."
                  className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3.5 py-2.5 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-pink-500/30"
                />
              </div>

              {/* Instagram */}
              <div className="space-y-1">
                <label className="text-xs text-slate-400 flex items-center gap-1.5 font-medium">
                  <Instagram className="w-3.5 h-3.5 text-pink-400" />
                  <span>Instagram (Opcional)</span>
                </label>
                <input 
                  type="text"
                  value={clientInstagram}
                  onChange={(e) => setClientInstagram(e.target.value)}
                  placeholder="@sofia_vel"
                  className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3.5 py-2.5 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-pink-500/30"
                />
              </div>

              {/* Special Instructions */}
              <div className="space-y-1">
                <label className="text-xs text-slate-400 flex items-center gap-1.5 font-medium">
                  <FileText className="w-3.5 h-3.5 text-pink-400" />
                  <span>Notas / Deseos de Color (Opcional)</span>
                </label>
                <textarea 
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={2}
                  placeholder="Ej: Me gustaría el set de Press-On Nails en tamaño M"
                  className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3.5 py-2.5 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-pink-500/30 resize-none"
                />
              </div>

              {errorMessage && (
                <div className="bg-red-950/30 border border-red-950 rounded-xl p-3 text-red-400 text-xs text-center">
                  {errorMessage}
                </div>
              )}

              <div className="pt-3">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full cursor-pointer bg-gradient-to-r from-pink-300 via-pink-400 to-pink-200 text-slate-950 font-display font-semibold uppercase tracking-wider text-xs py-3 rounded-xl hover:shadow-[0_0_15px_rgba(244,114,182,0.3)] transition-all flex items-center justify-center gap-2"
                >
                  {isSubmitting ? (
                    <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin"></div>
                  ) : (
                    <>
                      <span>Hacer Pedido (${selectedProduct.price * quantity}.00)</span>
                      <ChevronRight className="w-4 h-4" />
                    </>
                  )}
                </button>
                <span className="text-[10px] text-slate-500 block text-center mt-2">
                  La manicurista reservará tus artículos de boutique y te contactará.
                </span>
              </div>
            </form>
          </div>
        ) : (
          <div className="w-full lg:w-96 bg-slate-900/10 border border-slate-850 rounded-3xl p-6 text-center space-y-4 self-stretch flex flex-col justify-center py-16">
            <div className="w-12 h-12 bg-slate-900/60 rounded-full flex items-center justify-center mx-auto text-slate-500">
              <ShoppingBag className="w-5 h-5 text-pink-400/60" />
            </div>
            <div>
              <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">Detalles de la Solicitud</h4>
              <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto leading-relaxed">
                Seleccioná el botón <strong className="text-slate-400">"Solicitar"</strong> en cualquiera de los productos del catálogo para abrir el formulario instantáneo de pedidos.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
