/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface NailService {
  id: string;
  name: string;
  description: string;
  price: number;
  durationMinutes: number;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  imageUrl?: string;
  inStock: boolean;
}

export type AppointmentStatus = 'pendiente' | 'aceptado' | 'rechazado';

export interface Appointment {
  id: string;
  clientName: string;
  clientPhone: string;
  clientInstagram?: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:MM
  serviceId: string;
  serviceName: string;
  price: number;
  status: AppointmentStatus;
  notes?: string;
  createdAt: string;
  reminderSent?: boolean;
}

export type OrderStatus = 'pendiente' | 'listo' | 'entregado';

export interface ProductOrder {
  id: string;
  clientName: string;
  clientPhone: string;
  clientInstagram?: string;
  productId: string;
  productName: string;
  price: number;
  quantity: number;
  total: number;
  status: OrderStatus;
  notes?: string;
  createdAt: string;
}

export interface AdminSettings {
  shopName: string;
  welcomeMessage: string;
  whatsapp: string; // For real direct integration links (wa.me)
  instagram: string;
  address: string;
  adminPasswordHash: string; // Simplified password configuration
}

export interface DashboardStats {
  todayAppointmentsCount: number;
  pendingAppointmentsCount: number;
  pendingOrdersCount: number;
  totalClientsCount: number;
}
