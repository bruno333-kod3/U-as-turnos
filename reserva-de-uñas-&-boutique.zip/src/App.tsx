/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  MapPin, 
  Instagram, 
  Phone, 
  Lock, 
  X, 
  ShieldCheck, 
  Clock, 
  ArrowUpRight,
  ShoppingBag,
  Calendar,
  AlertCircle
} from 'lucide-react';
import { 
  NailService, 
  Product, 
  Appointment, 
  ProductOrder, 
  AdminSettings, 
  DashboardStats 
} from './types';
import Header from './components/Header';
import Footer from './components/Footer';
import BookingForm from './components/BookingForm';
import ProductCatalog from './components/ProductCatalog';
import AdminPanel from './components/AdminPanel';

export default function App() {
  // Global Catalogs & Lists
  const [services, setServices] = useState<NailService[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [orders, setOrders] = useState<ProductOrder[]>([]);
  const [shopSettings, setSettings] = useState<AdminSettings>({
    shopName: 'NailArt Elite Studio',
    welcomeMessage: 'Especialistas en manicura esculpida, kapping gel y diseños exclusivos diseñados en tonos rosa pastel y cromados plateados de alta fidelidad. ¡Reserva hoy tu turno online!',
    whatsapp: '+5491155556666',
    instagram: 'nailart_elite_studio',
    address: 'Av. Santa Fe 3400, Palermo, CABA',
    adminPasswordHash: 'admin123'
  });
  const [dashboardStats, setDashboardStats] = useState<DashboardStats>({
    todayAppointmentsCount: 0,
    pendingAppointmentsCount: 0,
    pendingOrdersCount: 0,
    totalClientsCount: 0
  });

  // UI Control states
  const [currentTab, setCurrentTab] = useState<'booking' | ' boutique'>('booking');
  const [isAdminMode, setIsAdminMode] = useState<boolean>(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState<boolean>(false);
  const [adminPasswordInput, setAdminPasswordInput] = useState<string>('');
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(false);
  const [loginError, setLoginError] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Load state check on load
  useEffect(() => {
    // Session token check
    const savedToken = sessionStorage.getItem('nailart_admin_token');
    if (savedToken) {
      setIsLoggedIn(true);
    }
    
    // Fetch all records
    fechAllData();
  }, []);

  const fechAllData = async () => {
    try {
      setIsLoading(true);
      const [resSettings, resServices, resProducts, resApts, resOrders, resStats] = await Promise.all([
        fetch('/api/settings').then(r => r.json()),
        fetch('/api/services').then(r => r.json()),
        fetch('/api/products').then(r => r.json()),
        fetch('/api/appointments').then(r => r.json()),
        fetch('/api/orders').then(r => r.json()),
        fetch('/api/dashboard/stats').then(r => r.json())
      ]);

      if (resSettings) setSettings(resSettings);
      if (resServices && Array.isArray(resServices)) setServices(resServices);
      if (resProducts && Array.isArray(resProducts)) setProducts(resProducts);
      if (resApts && Array.isArray(resApts)) setAppointments(resApts);
      if (resOrders && Array.isArray(resOrders)) setOrders(resOrders);
      if (resStats) setDashboardStats(resStats);
    } catch (err) {
      console.error('Error fetching data from API routing:', err);
      // Fallback states set locally if server isn't fully ready
    } finally {
      setIsLoading(false);
    }
  };

  // Sync dashboard stats separately when adjustments occur
  const fetchStats = async () => {
    try {
      const stats = await fetch('/api/dashboard/stats').then(r => r.json());
      if (stats) setDashboardStats(stats);
    } catch (e) {
      console.error(e);
    }
  };

  // Login handler
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    if (!adminPasswordInput) return;

    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password: adminPasswordInput })
      });
      const data = await res.json();
      
      if (data.success) {
        sessionStorage.setItem('nailart_admin_token', data.token);
        setIsLoggedIn(true);
        setIsAdminMode(true);
        setIsLoginModalOpen(false);
        setAdminPasswordInput('');
        fechAllData();
      } else {
        setLoginError(data.message || 'Contraseña incorrecta.');
      }
    } catch (err) {
      setLoginError('Problema al conectarse con el servidor de autenticación.');
    }
  };

  // Logout
  const handleLogout = () => {
    sessionStorage.removeItem('nailart_admin_token');
    setIsLoggedIn(false);
    setIsAdminMode(false);
  };

  // --- BUSINESS OPERATION FLOW ACTIONS Handlers (POSTs / PUTs) ---

  // Update Settings
  const handleUpdateSettings = async (settingsPayload: any) => {
    try {
      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settingsPayload)
      });
      const data = await res.json();
      if (data.success) {
        setSettings(data.settings);
        return true;
      }
      return false;
    } catch (err) {
      console.error(err);
      return false;
    }
  };

  // Submit Client Appointment Request (Turno)
  const handleSubmitBooking = async (bookingPayload: any) => {
    try {
      const res = await fetch('/api/appointments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(bookingPayload)
      });
      if (res.ok) {
        // Refresh local appointments list
        const updatedAptsRes = await fetch('/api/appointments').then(r => r.json());
        if (Array.isArray(updatedAptsRes)) setAppointments(updatedAptsRes);
        fetchStats();
        return true;
      }
      return false;
    } catch (err) {
      console.error(err);
      return false;
    }
  };

  // Submit Client Product Order Request
  const handleSubmitProductOrder = async (orderPayload: any) => {
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderPayload)
      });
      if (res.ok) {
        const updatedOrdersRes = await fetch('/api/orders').then(r => r.json());
        if (Array.isArray(updatedOrdersRes)) setOrders(updatedOrdersRes);
        fetchStats();
        return true;
      }
      return false;
    } catch (err) {
      console.error(err);
      return false;
    }
  };

  // Accept / Reject Appointment
  const handleUpdateAppointmentStatus = async (id: string, status: string) => {
    try {
      const res = await fetch(`/api/appointments/${id}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      if (res.ok) {
        // Refresh
        const updatedApts = await fetch('/api/appointments').then(r => r.json());
        if (Array.isArray(updatedApts)) setAppointments(updatedApts);
        fetchStats();
        return true;
      }
      return false;
    } catch (e) {
      console.error(e);
      return false;
    }
  };

  // Simulate Trigger Reminder
  const handleTriggerReminder = async (id: string) => {
    try {
      const res = await fetch(`/api/appointments/${id}/remind`, { method: 'POST' });
      if (res.ok) {
        const updatedApts = await fetch('/api/appointments').then(r => r.json());
        if (Array.isArray(updatedApts)) setAppointments(updatedApts);
        return true;
      }
      return false;
    } catch (e) {
      console.error(e);
      return false;
    }
  };

  // Update Product Order request status
  const handleUpdateOrderStatus = async (id: string, status: string) => {
    try {
      const res = await fetch(`/api/orders/${id}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      if (res.ok) {
        const updatedOrders = await fetch('/api/orders').then(r => r.json());
        if (Array.isArray(updatedOrders)) setOrders(updatedOrders);
        fetchStats();
        return true;
      }
      return false;
    } catch (e) {
      console.error(e);
      return false;
    }
  };

  // Delete appointment
  const handleDeleteAppointment = async (id: string) => {
    try {
      const res = await fetch(`/api/appointments/${id}`, { method: 'DELETE' });
      if (res.ok) {
        const updatedApts = await fetch('/api/appointments').then(r => r.json());
        if (Array.isArray(updatedApts)) setAppointments(updatedApts);
        fetchStats();
        return true;
      }
      return false;
    } catch (e) {
      console.error(e);
      return false;
    }
  };

  // Delete product order catalog request
  const handleDeleteOrder = async (id: string) => {
    try {
      const res = await fetch(`/api/orders/${id}`, { method: 'DELETE' });
      if (res.ok) {
        const updatedOrders = await fetch('/api/orders').then(r => r.json());
        if (Array.isArray(updatedOrders)) setOrders(updatedOrders);
        fetchStats();
        return true;
      }
      return false;
    } catch (e) {
      console.error(e);
      return false;
    }
  };

  // --- NAIL SERVICES CATALOG CONFIGS ---
  const handleCreateService = async (servicePayload: any) => {
    try {
      const res = await fetch('/api/services', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(servicePayload)
      });
      if (res.ok) {
        const updatedServices = await fetch('/api/services').then(r => r.json());
        if (Array.isArray(updatedServices)) setServices(updatedServices);
        return true;
      }
      return false;
    } catch (e) {
      console.error(e);
      return false;
    }
  };

  const handleUpdateService = async (id: string, servicePayload: any) => {
    try {
      const res = await fetch(`/api/services/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(servicePayload)
      });
      if (res.ok) {
        const updatedServices = await fetch('/api/services').then(r => r.json());
        if (Array.isArray(updatedServices)) setServices(updatedServices);
        return true;
      }
      return false;
    } catch (e) {
      console.error(e);
      return false;
    }
  };

  const handleDeleteService = async (id: string) => {
    try {
      const res = await fetch(`/api/services/${id}`, { method: 'DELETE' });
      if (res.ok) {
        const updatedServices = await fetch('/api/services').then(r => r.json());
        if (Array.isArray(updatedServices)) setServices(updatedServices);
        return true;
      }
      return false;
    } catch (e) {
      console.error(e);
      return false;
    }
  };

  // --- SHOP PRODUCTS CATALOG CONFIGS ---
  const handleCreateProduct = async (productPayload: any) => {
    try {
      const res = await fetch('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(productPayload)
      });
      if (res.ok) {
        const updatedProds = await fetch('/api/products').then(r => r.json());
        if (Array.isArray(updatedProds)) setProducts(updatedProds);
        return true;
      }
      return false;
    } catch (e) {
      console.error(e);
      return false;
    }
  };

  const handleUpdateProduct = async (id: string, productPayload: any) => {
    try {
      const res = await fetch(`/api/products/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(productPayload)
      });
      if (res.ok) {
        const updatedProds = await fetch('/api/products').then(r => r.json());
        if (Array.isArray(updatedProds)) setProducts(updatedProds);
        return true;
      }
      return false;
    } catch (e) {
      console.error(e);
      return false;
    }
  };

  const handleDeleteProduct = async (id: string) => {
    try {
      const res = await fetch(`/api/products/${id}`, { method: 'DELETE' });
      if (res.ok) {
        const updatedProds = await fetch('/api/products').then(r => r.json());
        if (Array.isArray(updatedProds)) setProducts(updatedProds);
        return true;
      }
      return false;
    } catch (e) {
      console.error(e);
      return false;
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-pink-500/20 selection:text-pink-300">
      
      {/* Navbar Header */}
      <Header 
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        isAdminMode={isAdminMode}
        setIsAdminMode={setIsAdminMode}
        isLoggedIn={isLoggedIn}
        onLogout={handleLogout}
        onOpenLoginModal={() => {
          setLoginError('');
          setIsLoginModalOpen(true);
        }}
        shopName={shopSettings.shopName}
      />

      {/* Main Container */}
      <main className="flex-1 px-4 sm:px-10 py-8 space-y-10">

        {isLoading ? (
          <div className="h-96 flex flex-col items-center justify-center gap-4">
            <div className="w-10 h-10 border-4 border-pink-400 border-t-transparent rounded-full animate-spin"></div>
            <p className="text-xs text-slate-500 font-mono tracking-widest uppercase">Cargando Estudio...</p>
          </div>
        ) : (
          <>
            {/* VIEW 1: Standard Client Space with Tab routing */}
            {!isAdminMode ? (
              <div className="space-y-10">
                
                {/* Hero / Welcome Intro Banner section */}
                <section className="relative overflow-hidden bg-slate-900/25 border border-pink-500/10 rounded-3xl p-6 sm:p-10 flex flex-col md:flex-row items-center gap-8 justify-between">
                  <div className="absolute top-0 right-0 w-96 h-96 bg-pink-400/5 rounded-full filter blur-3xl pointer-events-none"></div>
                  
                  <div className="space-y-4 max-w-2xl text-left">
                    <div className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-pink-400"></span>
                      <span className="text-[10px] uppercase font-bold tracking-widest font-mono text-pink-400">Estudio Profesional de Diseño Coorporal</span>
                    </div>
                    <h2 className="text-3xl sm:text-5xl font-serif italic text-pink-100 tracking-wide font-medium leading-tight">
                      Estilo, Brillo & <br className="hidden sm:inline" />
                      <span className="text-white not-italic font-sans font-extrabold pb-1 uppercase tracking-tighter bg-gradient-to-r from-pink-300 via-slate-200 to-pink-200 bg-clip-text text-transparent">
                        Detalles Cromados
                      </span>
                    </h2>
                    <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                      {shopSettings.welcomeMessage || '¡Bienvenida! Reservá tu turno para esculpidas gel, semipermanentes o kappings, personalizándolos como quieras.'}
                    </p>

                    <div className="flex flex-wrap gap-4 pt-2 text-xs font-mono text-slate-500">
                      {shopSettings.address && (
                        <div className="flex items-center gap-1.5">
                          <MapPin className="w-3.5 h-3.5 text-pink-500/60" />
                          <span>{shopSettings.address}</span>
                        </div>
                      )}
                      <div className="flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-pink-500/60" />
                        <span>Sáb cerrado • Lun a Vie 09:30 - 20:00</span>
                      </div>
                    </div>
                  </div>

                  {/* Aesthetic nail illustration preview cards */}
                  <div className="w-48 h-48 bg-slate-950/40 rounded-3xl border border-pink-500/20 shadow-2xl shrink-0 flex flex-col justify-center items-center relative gap-2 shrink-0 overflow-hidden group">
                    <div className="absolute top-0 left-0 w-full h-full bg-slate-900/60 transition-colors group-hover:bg-slate-900/20 z-0"></div>
                    <div className="w-10 h-10 bg-gradient-to-tr from-pink-300 to-pink-100 rounded-full border border-slate-450/40 shadow-lg shadow-pink-500/20 flex items-center justify-center z-10 animate-pulse">
                      <Sparkles className="w-5 h-5 text-slate-950" />
                    </div>
                    <span className="text-xs text-white font-serif italic font-semibold tracking-wide z-10">Agenda Online</span>
                    <span className="text-[9px] text-pink-400/80 font-mono tracking-widest z-10">NAILART ELITE</span>
                  </div>
                </section>

                {/* Sub Tab selection */}
                {currentTab === 'booking' ? (
                  <section className="space-y-6">
                    <BookingForm 
                      services={services}
                      existingAppointments={appointments}
                      onSubmitBooking={handleSubmitBooking}
                      shopSettings={shopSettings}
                    />
                  </section>
                ) : (
                  <section className="space-y-6">
                    <ProductCatalog 
                      products={products}
                      onSubmitOrder={handleSubmitProductOrder}
                      shopSettings={shopSettings}
                    />
                  </section>
                )}
              </div>
            ) : (
              // VIEW 2: Authorized Admin space tabs container
              <AdminPanel 
                services={services}
                products={products}
                appointments={appointments}
                orders={orders}
                stats={dashboardStats}
                settings={shopSettings}
                onUpdateSettings={handleUpdateSettings}
                onCreateService={handleCreateService}
                onUpdateService={handleUpdateService}
                onDeleteService={handleDeleteService}
                onCreateProduct={handleCreateProduct}
                onUpdateProduct={handleUpdateProduct}
                onDeleteProduct={handleDeleteProduct}
                onUpdateAppointmentStatus={handleUpdateAppointmentStatus}
                onTriggerReminder={handleTriggerReminder}
                onUpdateOrderStatus={handleUpdateOrderStatus}
                onDeleteAppointment={handleDeleteAppointment}
                onDeleteOrder={handleDeleteOrder}
              />
            )}
          </>
        )}
      </main>

      {/* Footer info banner */}
      <Footer 
        shopName={shopSettings.shopName}
        instagram={shopSettings.instagram}
        address={shopSettings.address}
      />

      {/* ADMIN LOGS LOGIN MODAL POPUP */}
      {isLoginModalOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-slate-900 border border-pink-500/20 rounded-3xl p-6 sm:p-8 max-w-sm w-full shadow-2xl relative space-y-6">
            <button 
              onClick={() => setIsLoginModalOpen(false)}
              className="absolute top-4 right-4 text-slate-500 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="text-center space-y-2">
              <div className="w-12 h-12 bg-pink-500/10 rounded-full flex items-center justify-center mx-auto border border-pink-500/20">
                <Lock className="w-6 h-6 text-pink-300" />
              </div>
              <h3 className="text-xl font-serif italic text-pink-100 font-semibold">Acceso Administrador</h3>
              <p className="text-xs text-slate-400">Ingresa la contraseña de tu cuenta para ver y aceptar los turnos de tus clientas.</p>
            </div>

            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs text-slate-505 block font-medium">Contraseña de acceso:</label>
                <input
                  type="password"
                  required
                  autoFocus
                  placeholder="Contraseña por defecto: admin123"
                  value={adminPasswordInput}
                  onChange={(e) => setAdminPasswordInput(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-850 rounded-xl px-4 py-3 text-sm text-center text-white focus:outline-none focus:border-pink-500/40 tracking-wider"
                />
              </div>

              {loginError && (
                <div className="bg-red-950/30 border border-red-900/50 p-2.5 rounded-xl text-xs text-red-400 text-center flex items-center justify-center gap-1.5">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{loginError}</span>
                </div>
              )}

              <button
                type="submit"
                className="w-full py-3 cursor-pointer bg-gradient-to-r from-pink-300 via-pink-400 to-pink-200 text-slate-950 font-display font-semibold uppercase tracking-wider text-xs rounded-xl hover:shadow-[0_0_12px_rgba(244,114,182,0.3)] transition-all"
              >
                Ingresar al Panel
              </button>
            </form>
            
            <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-850/80 text-[10px] text-slate-500 leading-normal text-left">
              <strong>Tip de Seguridad:</strong> Podes cambiar esta contraseña en cualquier momento desde la pestaña "Estudio & Cuenta" del panel administrativo para adaptarlo a tu celular.
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
