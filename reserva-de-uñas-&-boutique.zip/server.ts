/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import { 
  NailService, 
  Product, 
  Appointment, 
  ProductOrder, 
  AdminSettings,
  AppointmentStatus,
  OrderStatus
} from './src/types';

const DATA_FILE_PATH = path.join(process.cwd(), 'data-store.json');

// Interface for database structure
interface DatabaseSchema {
  services: NailService[];
  products: Product[];
  appointments: Appointment[];
  orders: ProductOrder[];
  settings: AdminSettings;
}

// Initial/default seed data
const DEFAULT_DATABASE: DatabaseSchema = {
  services: [
    {
      id: 'srv-1',
      name: 'Esculpidas Gel & Chrome',
      description: 'Estructura completa en gel con acabado brillante, ideal para uñas largas con detalles gris cromado.',
      price: 45,
      durationMinutes: 90
    },
    {
      id: 'srv-2',
      name: 'Kapping Gel Pastel',
      description: 'Fina capa protectora que fortalece tus uñas naturales en tono rosa pastel dulce.',
      price: 30,
      durationMinutes: 60
    },
    {
      id: 'srv-3',
      name: 'Esmaltado Semipermanente',
      description: 'Esmaltado impecable de larga duración con decoración básica y brillo extremo.',
      price: 25,
      durationMinutes: 45
    },
    {
      id: 'srv-4',
      name: 'Soft Gel Full Art Custom',
      description: 'Uñas soft gel de rápida aplicación con diseños complejos dibujados a mano alzada.',
      price: 55,
      durationMinutes: 120
    }
  ],
  products: [
    {
      id: 'prod-1',
      name: 'Esmalte Pastel & Chrome Polish',
      description: 'Esmalte especial efecto cromado metálico reflejo de alto brillo seco rápido.',
      price: 12,
      inStock: true
    },
    {
      id: 'prod-2',
      name: 'Press-On Custom Set (Rosa Pastel)',
      description: 'Uñas acrílicas listas para pegar diseñadas a mano con detalles cromados y pegamento premium incluido.',
      price: 28,
      inStock: true
    },
    {
      id: 'prod-3',
      name: 'Aceite Reparador de Rosas para Cutículas',
      description: 'Fórmula hidratante con pétalos naturales de rosas para nutrir cutículas y lucir manos perfectas.',
      price: 8,
      inStock: true
    },
    {
      id: 'prod-4',
      name: 'Pegatina de Uñas Decó Líneas Cromadas',
      description: 'Planilla de stickers adhesivos con filamentos plata y cromados listos para decorar tus esmaltados.',
      price: 6,
      inStock: true
    }
  ],
  appointments: [
    {
      id: 'apt-1',
      clientName: 'Bianca Gómez',
      clientPhone: '+5491155550123',
      clientInstagram: 'bianca.gomez',
      date: new Date(Date.now() + 86400000).toISOString().split('T')[0], // Tomorrow
      time: '16:00',
      serviceId: 'srv-4',
      serviceName: 'Soft Gel Full Art Custom',
      price: 55,
      status: 'pendiente',
      notes: 'Me encantaría combinar rosa pastel pastel con detalles de líneas en gris cromado metálico.',
      createdAt: new Date().toISOString()
    },
    {
      id: 'apt-2',
      clientName: 'Sol Fernández',
      clientPhone: '+5491155556789',
      clientInstagram: 'sol_fer',
      date: new Date(Date.now() + 86400000).toISOString().split('T')[0], // Tomorrow
      time: '14:30',
      serviceId: 'srv-3',
      serviceName: 'Esmaltado Semipermanente',
      price: 25,
      status: 'aceptado',
      notes: 'Mi turno es para asistir a un casamiento el sábado.',
      createdAt: new Date().toISOString()
    },
    {
      id: 'apt-3',
      clientName: 'Martina Rossi',
      clientPhone: '+5491155559876',
      clientInstagram: 'martu_rossi',
      date: new Date().toISOString().split('T')[0], // Today
      time: '18:00',
      serviceId: 'srv-2',
      serviceName: 'Kapping Gel Pastel',
      price: 30,
      status: 'pendiente',
      notes: 'Primera vez que me hago uñas en este estudio!',
      createdAt: new Date().toISOString()
    }
  ],
  orders: [
    {
      id: 'ord-1',
      clientName: 'Valentina López',
      clientPhone: '+5491155552244',
      clientInstagram: 'valen_lopez1',
      productId: 'prod-1',
      productName: 'Esmalte Pastel & Chrome Polish',
      price: 12,
      quantity: 1,
      total: 12,
      status: 'pendiente',
      notes: 'Quiero retirarlo por el local mañana por la tarde, gracias!',
      createdAt: new Date().toISOString()
    }
  ],
  settings: {
    shopName: 'NailArt Elite Studio',
    welcomeMessage: 'Especialistas en manicura esculpida, kapping gel y diseños exclusivos diseñados en tonos rosa pastel y cromados plateados de alta fidelidad. ¡Reserva hoy tu turno online!',
    whatsapp: '+5491155556666',
    instagram: 'nailart_elite_studio',
    address: 'Av. Santa Fe 3400, Palermo, CABA',
    adminPasswordHash: 'admin123' // default password
  }
};

// Local cache database
let db: DatabaseSchema = { ...DEFAULT_DATABASE };

// Load database from file
function loadDatabase() {
  try {
    if (fs.existsSync(DATA_FILE_PATH)) {
      const data = fs.readFileSync(DATA_FILE_PATH, 'utf-8');
      const parsed = JSON.parse(data);
      // Ensure structure is correct
      db = {
        services: parsed.services || [],
        products: parsed.products || [],
        appointments: parsed.appointments || [],
        orders: parsed.orders || [],
        settings: { ...DEFAULT_DATABASE.settings, ...(parsed.settings || {}) }
      };
      console.log('Database loaded successfully from file.');
    } else {
      console.log('Data file not found. Re-creating with default seed data.');
      saveDatabase();
    }
  } catch (err) {
    console.error('Error loading database, using default seeds:', err);
  }
}

// Save database to file
function saveDatabase() {
  try {
    const dir = path.dirname(DATA_FILE_PATH);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(DATA_FILE_PATH, JSON.stringify(db, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving data to file:', err);
  }
}

// Initial load
loadDatabase();

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Add middlewares
  app.use(express.json());

  // --- API API ENDPOINTS ---

  // Get Store Public Settings
  app.get('/api/settings', (req, res) => {
    // Return settings WITHOUT exposing password directly
    const { adminPasswordHash, ...publicSettings } = db.settings;
    res.json(publicSettings);
  });

  // Admin login check
  app.post('/api/login', (req, res) => {
    const { password } = req.body;
    if (password === db.settings.adminPasswordHash) {
      res.json({ success: true, token: 'session_nailart_token_secure_' + Date.now() });
    } else {
      res.status(401).json({ success: false, message: 'Contraseña incorrecta' });
    }
  });

  // Update Store Settings
  app.put('/api/settings', (req, res) => {
    const { shopName, welcomeMessage, whatsapp, instagram, address, newPassword } = req.body;
    
    if (shopName) db.settings.shopName = shopName;
    if (welcomeMessage !== undefined) db.settings.welcomeMessage = welcomeMessage;
    if (whatsapp) db.settings.whatsapp = whatsapp;
    if (instagram) db.settings.instagram = instagram;
    if (address !== undefined) db.settings.address = address;
    if (newPassword) db.settings.adminPasswordHash = newPassword;

    saveDatabase();
    // Return updated without exposing hashing
    const { adminPasswordHash, ...publicSettings } = db.settings;
    res.json({ success: true, settings: publicSettings });
  });

  // Get Services
  app.get('/api/services', (req, res) => {
    res.json(db.services);
  });

  // Create Service
  app.post('/api/services', (req, res) => {
    const { name, description, price, durationMinutes } = req.body;
    if (!name || isNaN(Number(price))) {
      return res.status(400).json({ error: 'Nombre y precio numérico válidos requeridos.' });
    }
    const newService: NailService = {
      id: 'srv-' + Date.now(),
      name,
      description: description || '',
      price: Number(price),
      durationMinutes: Number(durationMinutes) || 60
    };
    db.services.push(newService);
    saveDatabase();
    res.status(201).json(newService);
  });

  // Update Service
  app.put('/api/services/:id', (req, res) => {
    const { name, description, price, durationMinutes } = req.body;
    const index = db.services.findIndex(s => s.id === req.params.id);
    if (index === -1) {
      return res.status(404).json({ error: 'Servicio no encontrado' });
    }
    if (name) db.services[index].name = name;
    if (description !== undefined) db.services[index].description = description;
    if (price !== undefined && !isNaN(Number(price))) db.services[index].price = Number(price);
    if (durationMinutes !== undefined && !isNaN(Number(durationMinutes))) {
      db.services[index].durationMinutes = Number(durationMinutes);
    }
    saveDatabase();
    res.json(db.services[index]);
  });

  // Delete Service
  app.delete('/api/services/:id', (req, res) => {
    const index = db.services.findIndex(s => s.id === req.params.id);
    if (index === -1) {
      return res.status(404).json({ error: 'Servicio no encontrado' });
    }
    const deleted = db.services.splice(index, 1);
    saveDatabase();
    res.json({ success: true, deleted: deleted[0] });
  });

  // Get Products
  app.get('/api/products', (req, res) => {
    res.json(db.products);
  });

  // Create Product
  app.post('/api/products', (req, res) => {
    const { name, description, price, inStock } = req.body;
    if (!name || isNaN(Number(price))) {
      return res.status(400).json({ error: 'Nombre y precio de producto requeridos.' });
    }
    const newProduct: Product = {
      id: 'prod-' + Date.now(),
      name,
      description: description || '',
      price: Number(price),
      inStock: inStock !== undefined ? Boolean(inStock) : true
    };
    db.products.push(newProduct);
    saveDatabase();
    res.status(201).json(newProduct);
  });

  // Update Product
  app.put('/api/products/:id', (req, res) => {
    const { name, description, price, inStock } = req.body;
    const index = db.products.findIndex(p => p.id === req.params.id);
    if (index === -1) {
      return res.status(404).json({ error: 'Producto no encontrado' });
    }
    if (name) db.products[index].name = name;
    if (description !== undefined) db.products[index].description = description;
    if (price !== undefined && !isNaN(Number(price))) db.products[index].price = Number(price);
    if (inStock !== undefined) db.products[index].inStock = Boolean(inStock);
    saveDatabase();
    res.json(db.products[index]);
  });

  // Delete Product
  app.delete('/api/products/:id', (req, res) => {
    const index = db.products.findIndex(p => p.id === req.params.id);
    if (index === -1) {
      return res.status(404).json({ error: 'Producto no encontrado' });
    }
    const deleted = db.products.splice(index, 1);
    saveDatabase();
    res.json({ success: true, deleted: deleted[0] });
  });

  // Get Appointments (Turnos)
  app.get('/api/appointments', (req, res) => {
    res.json(db.appointments);
  });

  // Create Appointment (Turno)
  app.post('/api/appointments', (req, res) => {
    const { clientName, clientPhone, clientInstagram, date, time, serviceId, notes } = req.body;
    
    if (!clientName || !clientPhone || !date || !time || !serviceId) {
      return res.status(400).json({ error: 'Faltan campos obligatorios para agendar tu turno.' });
    }

    const service = db.services.find(s => s.id === serviceId);
    if (!service) {
      return res.status(404).json({ error: 'El servicio solicitado no está disponible.' });
    }

    const newAppointment: Appointment = {
      id: 'apt-' + Date.now(),
      clientName,
      clientPhone,
      clientInstagram: clientInstagram || '',
      date,
      time,
      serviceId,
      serviceName: service.name,
      price: service.price,
      status: 'pendiente',
      notes: notes || '',
      createdAt: new Date().toISOString(),
      reminderSent: false
    };

    db.appointments.push(newAppointment);
    saveDatabase();
    res.status(201).json(newAppointment);
  });

  // Update Appointment Status
  app.put('/api/appointments/:id/status', (req, res) => {
    const { status } = req.body;
    if (!['pendiente', 'aceptado', 'rechazado'].includes(status)) {
      return res.status(400).json({ error: 'Estado de turno inválido.' });
    }
    const index = db.appointments.findIndex(a => a.id === req.params.id);
    if (index === -1) {
      return res.status(404).json({ error: 'Turno no encontrado.' });
    }
    db.appointments[index].status = status as AppointmentStatus;
    saveDatabase();
    res.json(db.appointments[index]);
  });

  // Trigger simulated reminder / Set reminderSent = true
  app.post('/api/appointments/:id/remind', (req, res) => {
    const index = db.appointments.findIndex(a => a.id === req.params.id);
    if (index === -1) {
      return res.status(404).json({ error: 'Turno no encontrado.' });
    }
    db.appointments[index].reminderSent = true;
    saveDatabase();
    res.json({ success: true, appointment: db.appointments[index] });
  });

  // Get Product Requests (Pedidos de Boutique)
  app.get('/api/orders', (req, res) => {
    res.json(db.orders);
  });

  // Create Product Request (Pedido)
  app.post('/api/orders', (req, res) => {
    const { clientName, clientPhone, clientInstagram, productId, quantity, notes } = req.body;

    if (!clientName || !clientPhone || !productId || !quantity) {
      return res.status(400).json({ error: 'Nombre, teléfono, producto y cantidad son necesarios.' });
    }

    const product = db.products.find(p => p.id === productId);
    if (!product) {
      return res.status(404).json({ error: 'Ese producto no existe en el catálogo.' });
    }

    const orderQty = Math.max(1, Number(quantity));
    const newOrder: ProductOrder = {
      id: 'ord-' + Date.now(),
      clientName,
      clientPhone,
      clientInstagram: clientInstagram || '',
      productId,
      productName: product.name,
      price: product.price,
      quantity: orderQty,
      total: product.price * orderQty,
      status: 'pendiente',
      notes: notes || '',
      createdAt: new Date().toISOString()
    };

    db.orders.push(newOrder);
    saveDatabase();
    res.status(201).json(newOrder);
  });

  // Update Order Status
  app.put('/api/orders/:id/status', (req, res) => {
    const { status } = req.body;
    if (!['pendiente', 'listo', 'entregado'].includes(status)) {
      return res.status(400).json({ error: 'Estado del pedido inválido.' });
    }
    const index = db.orders.findIndex(o => o.id === req.params.id);
    if (index === -1) {
      return res.status(404).json({ error: 'Pedido no encontrado.' });
    }
    db.orders[index].status = status as OrderStatus;
    saveDatabase();
    res.json(db.orders[index]);
  });

  // DELETE single appointment (clean up)
  app.delete('/api/appointments/:id', (req, res) => {
    const index = db.appointments.findIndex(a => a.id === req.params.id);
    if (index === -1) return res.status(404).json({ error: 'Turno no encontrado.' });
    db.appointments.splice(index, 1);
    saveDatabase();
    res.json({ success: true });
  });

  // DELETE single order (clean up)
  app.delete('/api/orders/:id', (req, res) => {
    const index = db.orders.findIndex(o => o.id === req.params.id);
    if (index === -1) return res.status(404).json({ error: 'Pedido no encontrado.' });
    db.orders.splice(index, 1);
    saveDatabase();
    res.json({ success: true });
  });

  // Dashboard Stats
  app.get('/api/dashboard/stats', (req, res) => {
    const todayStr = new Date().toISOString().split('T')[0];
    const todayAppointmentsCount = db.appointments.filter(a => a.date === todayStr && a.status !== 'rechazado').length;
    const pendingAppointmentsCount = db.appointments.filter(a => a.status === 'pendiente').length;
    const pendingOrdersCount = db.orders.filter(o => o.status === 'pendiente').length;
    
    // Total clients count
    const clientPhoneSet = new Set<string>();
    db.appointments.forEach(a => clientPhoneSet.add(a.clientPhone));
    db.orders.forEach(o => clientPhoneSet.add(o.clientPhone));
    const totalClientsCount = clientPhoneSet.size;

    res.json({
      todayAppointmentsCount,
      pendingAppointmentsCount,
      pendingOrdersCount,
      totalClientsCount
    });
  });

  // --- VITE MIDDLEWARE & CLIENT ROUTING ---

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Server] Running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
